// ============================================================================
// RECIPENDENT APP - EMPTY STATE COMPONENT
// ============================================================================
// Anzeige wenn keine Daten vorhanden sind
// ============================================================================

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Animated, { FadeIn } from 'react-native-reanimated';
import DesignSystem from '../../../config/designSystem';

const emptyState = ({
  icon = 'clipboard-text-outline',
  title = 'Keine Daten',
  subtitle = null
}) => {
  return (
    <Animated.View entering={FadeIn.duration(500)} style={styles.container}>
      <View style={styles.iconContainer}>
        <MaterialCommunityIcons name={icon} size={64} color={DesignSystem.colors.textTertiary} />
      </View>
      <Text style={styles.title}>{title}</Text>
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 40,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: DesignSystem.colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    ...DesignSystem.typography.h3,
    color: DesignSystem.colors.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    ...DesignSystem.typography.body,
    color: DesignSystem.colors.textTertiary,
    textAlign: 'center',
  },
});

export default emptyState;
