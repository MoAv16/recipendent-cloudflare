// ============================================================================
// RECIPENDENT APP - RECIPE CARD COMPONENT (FIXED LAYOUT)
// ============================================================================
// Card-Darstellung für Aufträge/Rezepte im Dashboard
// Mit festem Layout und Long-Press für Admin-Aktionen
// ============================================================================

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Animated } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import DesignSystem from '../../../config/designSystem';
import BrandConfig from '../../../config/brandConfig';
import { useTheme } from '../../../shared/themeContext';
import ActionSheet from '../../../shared/components/ActionSheet';
import { TimeUtils } from '../../../shared/utils/timeUtils';

const recipeCard = ({
  order,
  onPress,
  onEdit,
  onDelete,
  isCritical = false,
  isAdmin = false,
  allTeamMembers = [], // Array aller Team-Mitglieder für "Team" Check
}) => {
  const { currentTheme } = useTheme();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);
  const [actionSheetVisible, setActionSheetVisible] = useState(false);

  // ============================================================================
  // STATUS BERECHNUNG (Kritisch vs. Überfällig)
  // ============================================================================
  const isOverdue = TimeUtils.isOverdue(order.due_date);
  const isCriticalStatus = order.status === 'critical' || isCritical;
  const isDone = order.status === 'done';

  // ============================================================================
  // PULSING ANIMATION (nur für kritische Aufträge)
  // ============================================================================
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (isCriticalStatus && !isDone) {
      // Pulsing animation loop
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.15,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      // Stop animation and reset
      pulseAnim.setValue(1);
    }
  }, [isCriticalStatus, isDone]);

  const handleLongPress = () => {
    if (isAdmin) {
      setActionSheetVisible(true);
    }
  };

  const handleRename = () => {
    if (onEdit) {
      onEdit();
    }
  };

  const handleDelete = () => {
    if (onDelete) {
      onDelete();
    }
  };

  // ============================================================================
  // HELPER FUNCTIONS (Drei Status-Zustände)
  // ============================================================================

  // Status Helper - Unterscheidung: Kritisch (pulsierend), Überfällig (statisch rot), Aktiv (grün), Erledigt (blau)
  const getStatusColor = () => {
    if (isDone) return DesignSystem.colors.statusDone; // Blau
    if (isCriticalStatus) return DesignSystem.colors.statusCritical; // Rot (pulsierend)
    if (isOverdue) return DesignSystem.colors.danger; // Statisch Rot (überfällig)
    return DesignSystem.colors.statusOpen; // Grün (aktiv)
  };

  const getStatusLabel = () => {
    if (isDone) return 'Erledigt';
    if (isCriticalStatus) return 'Kritisch';
    if (isOverdue) return 'Überfällig';
    return 'Aktiv';
  };

  // Status-Farben für Gradient
  const getStatusColors = () => {
    if (isDone) return [DesignSystem.colors.statusDone, BrandConfig.adjustColor(DesignSystem.colors.statusDone, -10)];
    if (isCriticalStatus) return [DesignSystem.colors.statusCritical, BrandConfig.adjustColor(DesignSystem.colors.statusCritical, -10)];
    if (isOverdue) return [DesignSystem.colors.danger, BrandConfig.adjustColor(DesignSystem.colors.danger, -10)];
    return [DesignSystem.colors.statusOpen, BrandConfig.adjustColor(DesignSystem.colors.statusOpen, -10)];
  };

  // Author Name formatieren: "Vorname N."
  const formatAuthorName = () => {
    if (!order.author_name) return 'Unbekannt';
    const parts = order.author_name.trim().split(' ');
    if (parts.length === 1) return parts[0];
    const firstName = parts[0];
    const lastNameInitial = parts[parts.length - 1][0];
    return `${firstName} ${lastNameInitial}.`;
  };



  // Assignment formatieren - returns string with names (max 4) or count
  const formatAssignment = () => {
    if (!order.assigned_to || order.assigned_to.length === 0) return null;

    const assignedCount = order.assigned_to.length;
    const totalTeamMembers = allTeamMembers.length || 0;

    // Alle Team-Mitglieder zugewiesen
    if (totalTeamMembers > 0 && assignedCount === totalTeamMembers) {
      return 'Team';
    }

    // Wenn wir User-Details haben, zeige Namen
    if (order.assignedUsers && order.assignedUsers.length > 0) {
      // Bei mehr als 4 Zugewiesenen: "X Personen" anzeigen
      if (assignedCount > 4) {
        return `${assignedCount} Personen`;
      }

      // Bei 1-4 Personen: Namen anzeigen
      const names = order.assignedUsers.map(user => {
        const userName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
        if (userName) {
          const parts = userName.split(' ');
          if (parts.length === 1) return parts[0];
          const firstName = parts[0];
          const lastNameInitial = parts[parts.length - 1][0];
          return `${firstName} ${lastNameInitial}.`;
        }
        return 'Unbekannt';
      });

      return names.join(', ');
    }

    // Fallback
    return `${assignedCount} ${assignedCount === 1 ? 'Person' : 'Personen'}`;
  };

  // Priority Style
  const getPriorityColor = () => {
    if (!order.priority) return null;
    const colors = {
      1: DesignSystem.colors.priority1,
      2: DesignSystem.colors.priority2,
      3: DesignSystem.colors.priority3,
      4: DesignSystem.colors.priority4,
    };
    return colors[order.priority] || DesignSystem.colors.textTertiary;
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  const assignmentText = formatAssignment();

  return (
    <>
      <TouchableOpacity
        onPress={onPress}
        onLongPress={handleLongPress}
        activeOpacity={0.9}
      >
        <View style={styles.cardContainer}>
          {/* ===== STATUS BALKEN (Mit Pulsing-Animation für Kritisch) ===== */}
          <Animated.View
            style={{
              transform: [{ scaleY: isCriticalStatus && !isDone ? pulseAnim : 1 }],
            }}
          >
            <LinearGradient
              colors={getStatusColors()}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.statusBar}
            />
          </Animated.View>

          <View style={styles.content}>
            {/* ===== HEADER MIT TITEL UND BILD ===== */}
            <View style={styles.header}>
              {/* Titel + Category */}
              <View style={styles.headerLeft}>
                <Text style={styles.title} numberOfLines={2}>
                  {order.title}
                </Text>
                {order.category && (
                  <View style={styles.categoryBadge}>
                    <Text style={styles.categoryText}>{order.category}</Text>
                  </View>
                )}
              </View>

              {/* Bild (fest fixierte Position) */}
              <View style={styles.imageContainer}>
                {order.image_url ? (
                  <Image
                    source={{ uri: order.image_url }}
                    style={styles.orderImage}
                  />
                ) : (
                  <View style={styles.imagePlaceholder}>
                    <MaterialCommunityIcons
                      name="image-outline"
                      size={32}
                      color={currentTheme.colors.textTertiary}
                    />
                  </View>
                )}
              </View>
            </View>

            {/* ===== DESCRIPTION ===== */}
            {order.description && (
              <Text style={styles.description} numberOfLines={3}>
                {order.description}
              </Text>
            )}

            {/* ===== DETAILS GRID ===== */}
            <View style={styles.detailsContainer}>
              {/* Priority Corner (Bottom Right) */}
              {order.priority && getPriorityColor() && (
                <LinearGradient
                  colors={[
                    currentTheme.isDark
                      ? `${getPriorityColor()}00`
                      : `${getPriorityColor()}00`,
                    `${getPriorityColor()}40`,
                    `${getPriorityColor()}80`,
                    getPriorityColor()
                  ]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.priorityCorner}
                >
                  <Text style={styles.priorityTextCorner}>P{order.priority}</Text>
                </LinearGradient>
              )}

              {/* Zeile 1: Autor + Zugewiesen an */}
              <View style={styles.detailsRow}>
                <View style={styles.detailItem}>
                  <View style={styles.detailIconLabel}>
                    {order.author?.profile_picture ? (
                      <Image
                        source={{ uri: order.author.profile_picture }}
                        style={styles.authorAvatar}
                      />
                    ) : (
                      <View style={styles.avatarPlaceholder}>
                        <MaterialCommunityIcons
                          name="account"
                          size={12}
                          color={currentTheme.colors.textSecondary}
                        />
                      </View>
                    )}
                    <Text style={styles.detailValue} numberOfLines={1}>
                      {formatAuthorName()}
                    </Text>
                  </View>
                </View>

                {assignmentText && (
                  <View style={styles.detailItem}>
                    <View style={styles.detailIconLabel}>
                      <MaterialCommunityIcons
                        name="account-multiple"
                        size={18}
                        color={currentTheme.colors.textSecondary}
                      />
                      <Text style={styles.detailLabel}>Zugewiesen an</Text>
                    </View>
                    <Text style={styles.detailValue} numberOfLines={2}>
                      {assignmentText}
                    </Text>
                  </View>
                )}
              </View>

              {/* Zeile 2: Fälligkeit + Kunde */}
              <View style={styles.detailsRow}>
                {order.due_date && (
                  <View style={styles.detailItem}>
                    <View style={styles.detailIconLabel}>
                      <MaterialCommunityIcons
                        name="clock-outline"
                        size={16}
                        color={(isCriticalStatus || isOverdue) ? DesignSystem.colors.danger : currentTheme.colors.textSecondary}
                      />
                      <Text style={[styles.detailLabel, (isCriticalStatus || isOverdue) && styles.criticalText]}>
                        Fälligkeit
                      </Text>
                    </View>
                    <Text
                      style={[
                        styles.detailValue,
                        (isCriticalStatus || isOverdue) && styles.criticalText,
                      ]}
                      numberOfLines={1}
                    >
                      {TimeUtils.formatCountdown(order.due_date)}
                    </Text>
                  </View>
                )}

                {order.customer_name && (
                  <View style={styles.detailItem}>
                    <View style={styles.detailIconLabel}>
                      <MaterialCommunityIcons
                        name="account-tie"
                        size={16}
                        color={currentTheme.colors.textSecondary}
                      />
                      <Text style={styles.detailLabel}>Kunde</Text>
                    </View>
                    <Text style={styles.detailValue} numberOfLines={1} ellipsizeMode="tail">
                      {order.customer_name}
                    </Text>
                  </View>
                )}
              </View>

              {/* Zeile 3: Ort */}
              <View style={styles.detailsRow}>
                {order.location && (
                  <View style={styles.detailItem}>
                    <View style={styles.detailIconLabel}>
                      <MaterialCommunityIcons
                        name="map-marker"
                        size={16}
                        color={currentTheme.colors.textSecondary}
                      />
                      <Text style={styles.detailLabel}>Ort</Text>
                    </View>
                    <Text style={styles.detailValue} numberOfLines={1} ellipsizeMode="tail">
                      {order.location}
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Admin Edit Icon (oben rechts wenn Admin) */}
            {isAdmin && onEdit && (
              <TouchableOpacity
                style={styles.editIcon}
                onPress={onEdit}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <MaterialCommunityIcons
                  name="cog"
                  size={18}
                  color={currentTheme.colors.textSecondary}
                />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </TouchableOpacity>

      {/* Action Sheet für Long-Press (nur für Admins) */}
      {isAdmin && (
        <ActionSheet
          visible={actionSheetVisible}
          onClose={() => setActionSheetVisible(false)}
          onRename={handleRename}
          onDelete={handleDelete}
          title={order.title}
          itemType="Auftrag"
        />
      )}
    </>
  );
};

// ============================================================================
// STYLES
// ============================================================================

const createStyles = (theme) => StyleSheet.create({
  cardContainer: {
    marginBottom: DesignSystem.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderRadius: DesignSystem.borderRadius.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
    overflow: 'hidden',
    ...DesignSystem.shadows.md,
  },
  statusBar: {
    height: 6,
  },
  content: {
    padding: DesignSystem.spacing.xl,
    paddingBottom: DesignSystem.spacing.xl,
    position: 'relative',
  },

  // ===== HEADER =====
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: DesignSystem.spacing.md,
    gap: DesignSystem.spacing.md,
  },
  headerLeft: {
    flex: 1,
  },
  title: {
    ...DesignSystem.typography.h4,
    color: theme.colors.text,
    marginBottom: DesignSystem.spacing.xs,
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    backgroundColor: theme.colors.surfaceVariant,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: DesignSystem.borderRadius.sm,
  },
  categoryText: {
    ...DesignSystem.typography.caption,
    fontWeight: '600',
    color: theme.colors.textSecondary,
  },

  // ===== BILD (FEST FIXIERT) =====
  imageContainer: {
    width: 80,
    height: 80,
  },
  orderImage: {
    width: 80,
    height: 80,
    borderRadius: DesignSystem.borderRadius.md,
    backgroundColor: theme.colors.surfaceVariant,
  },
  imagePlaceholder: {
    width: 80,
    height: 80,
    borderRadius: DesignSystem.borderRadius.md,
    backgroundColor: theme.colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // ===== DESCRIPTION =====
  description: {
    ...DesignSystem.typography.bodySmall,
    color: theme.colors.textSecondary,
    marginBottom: DesignSystem.spacing.lg,
    lineHeight: 20,
  },

  // ===== DETAILS GRID =====
  detailsContainer: {
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    padding: DesignSystem.spacing.md,
    gap: DesignSystem.spacing.md,
    position: 'relative',
    overflow: 'hidden',
  },
  detailsRow: {
    flexDirection: 'row',
    gap: DesignSystem.spacing.md,
  },
  detailItem: {
    flex: 1,
    gap: DesignSystem.spacing.xs,
  },
  detailIconLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailLabel: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  detailValue: {
    ...DesignSystem.typography.bodySmall,
    color: theme.colors.text,
    fontWeight: '500',
  },
  criticalText: {
    color: DesignSystem.colors.danger,
    fontWeight: '700',
  },

  // Author Avatar
  authorAvatar: {
    width: 30,
    height: 30,
    borderRadius: 20,
    backgroundColor: theme.colors.surfaceVariant,
  },
  avatarPlaceholder: {
    width: 30,
    height: 30,
    borderRadius: 20,
    backgroundColor: theme.colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Priority Corner (Bottom Right with Gradient)
  priorityCorner: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 100,
    height: 35,
    borderTopLeftRadius: DesignSystem.borderRadius.xxl,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    paddingBottom: DesignSystem.spacing.sm,
    paddingRight: DesignSystem.spacing.sm,
  },
  priorityTextCorner: {
    fontSize: 20,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: 1.5,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },

  // Edit Icon (Admin only)
  editIcon: {
    position: 'absolute',
    top: DesignSystem.spacing.sm,
    right: DesignSystem.spacing.sm,
    padding: 6,
    borderRadius: DesignSystem.borderRadius.sm,
    backgroundColor: theme.colors.surfaceVariant,
  },
});

export default recipeCard;