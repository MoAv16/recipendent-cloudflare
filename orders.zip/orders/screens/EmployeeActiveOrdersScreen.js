import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Image,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useAuth } from '../../auth/authContext';
import { getOrders } from '../services/crudOperations';
import { subscribeToOrders } from '../services/realtimeService';
import { useTheme } from '../../../shared/themeContext';
import { useToast } from '../../../shared/components/Toast';
import { useBranding } from '../../../shared/brandingContext';
import GlassCard from '../../../shared/components/GlassCard';
import { TimeUtils } from '../../../shared/utils/timeUtils';

export default function EmployeeActiveOrdersScreen({ navigation }) {
  const { company, user } = useAuth();
  const { currentTheme } = useTheme();
  const { showToast } = useToast();
  const { primaryColor } = useBranding();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Nur beim ersten Mount laden - Realtime übernimmt danach alle Updates
  useEffect(() => {
    if (company?.id) {
      loadOrders();
    } else {
      // Kein Company gefunden - Loading beenden
      setLoading(false);
    }
  }, [company?.id]); // Company ID als dependency

  // Realtime Subscription - Live Updates ohne Reload
  useEffect(() => {
    const unsubscribe = subscribeToOrders(
      (newOrder) => {
        if (newOrder.status === 'open') {
          console.log('🔴 [Realtime] Neuer Auftrag:', newOrder.title);
          setOrders(prev => [newOrder, ...prev]);
        }
      },
      (updatedOrder) => {
        console.log('🔴 [Realtime] Auftrag aktualisiert:', updatedOrder.title);
        if (updatedOrder.status === 'open') {
          setOrders(prev => {
            const exists = prev.find(o => o.id === updatedOrder.id);
            if (exists) {
              return prev.map(o => o.id === updatedOrder.id ? updatedOrder : o);
            } else {
              return [updatedOrder, ...prev];
            }
          });
        } else {
          // Status auf done/completed - aus Liste entfernen
          setOrders(prev => prev.filter(o => o.id !== updatedOrder.id));
        }
      },
      (deletedOrder) => {
        console.log('🔴 [Realtime] Auftrag gelöscht:', deletedOrder.id);
        setOrders(prev => prev.filter(o => o.id !== deletedOrder.id));
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []); // Keine Dependencies - Subscription bleibt aktiv

  const loadOrders = async () => {
    try {
      setLoading(true);

      const data = await getOrders('open'); // Nur offene Orders
      setOrders(data || []);
    } catch (error) {
      console.error('Fehler beim Laden der Aufträge:', error);
      showToast({
        message: 'Aufträge konnten nicht geladen werden',
        type: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const getPriorityColor = (priority) => {
    const colors = ['#F44336', '#FF9800', '#FFC107', '#4CAF50'];
    return colors[priority - 1] || '#9E9E9E';
  };

  const renderOrderCard = ({ item }) => (
    <GlassCard
      intensity={40}
      style={styles.orderCard}
      onPress={() => navigation.navigate('OrderDetail', { orderId: item.id, isEmployee: true })}
    >
      <View style={styles.orderHeader}>
        <Text style={styles.orderTitle}>
          {item.title}
        </Text>
        {item.priority && (
          <View style={[styles.priorityBadge, { backgroundColor: getPriorityColor(item.priority) }]}>
            <Text style={styles.priorityText}>P{item.priority}</Text>
          </View>
        )}
      </View>

      <Text style={styles.orderDescription} numberOfLines={2}>
        {item.description}
      </Text>

      {item.location && (
        <Text style={styles.orderLocation}>
          📍 {item.location}
        </Text>
      )}

      {item.due_date && (
        <Text style={styles.orderDueDate}>
          ⏰ {TimeUtils.formatDateTime(item.due_date)}
        </Text>
      )}

      <View style={styles.orderFooter}>
        <Text style={styles.orderAuthor}>
          von {item.author_name || 'Unbekannt'}
        </Text>
        <View style={[styles.statusBadge, styles.statusOpen]}>
          <Text style={styles.statusText}>Offen</Text>
        </View>
      </View>
    </GlassCard>
  );

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, styles.centerContent]} edges={['top', 'left', 'right']}>
        <ActivityIndicator size="large" color={primaryColor} />
        <Text style={styles.loadingText}>
          Aufträge werden geladen...
        </Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <StatusBar style="auto" />

      {company?.logo && (
        <Image source={{ uri: company.logo }} style={styles.logo} />
      )}
      <Text style={styles.dashboardTitle}>
        Meine Aufträge
      </Text>

      <FlatList
        data={orders}
        keyExtractor={(item) => item.id}
        renderItem={renderOrderCard}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[primaryColor]}
            tintColor={primaryColor}
          />
        }
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            Keine aktiven Aufträge
          </Text>
        }
      />
    </SafeAreaView>
  );
}

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },
  centerContent: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: theme.colors.textSecondary,
  },
  loadingTextDark: {
    color: theme.colors.textSecondary,
  },
  logo: {
    width: 50,
    height: 50,
    borderRadius: 8,
    margin: 16,
  },
  dashboardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: theme.colors.text,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  dashboardTitleDark: {
    color: theme.colors.text,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 100,
  },
  orderCard: {
    backgroundColor: theme.colors.surfaceVariant,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  orderCardDark: {
    backgroundColor: theme.colors.surface,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  orderTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.text,
    flex: 1,
  },
  orderTitleDark: {
    color: theme.colors.text,
  },
  orderDescription: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: 8,
  },
  orderDescriptionDark: {
    color: theme.colors.textSecondary,
  },
  orderLocation: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: 4,
  },
  orderLocationDark: {
    color: theme.colors.textSecondary,
  },
  orderDueDate: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: 8,
  },
  orderDueDateDark: {
    color: theme.colors.textSecondary,
  },
  orderFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  orderAuthor: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  orderAuthorDark: {
    color: theme.colors.textSecondary,
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginLeft: 8,
  },
  priorityText: {
    color: theme.colors.text,
    fontSize: 12,
    fontWeight: '600',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusOpen: {
    backgroundColor: '#4CAF50',
  },
  statusText: {
    color: theme.colors.text,
    fontSize: 12,
    fontWeight: '600',
  },
  emptyText: {
    textAlign: 'center',
    color: theme.colors.text, // Besserer Kontrast in Dark Mode
    marginTop: 40,
    fontSize: 16,
  },
});
