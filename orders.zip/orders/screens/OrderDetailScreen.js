// ============================================================================
// RECIPENDENT APP - ORDER DETAIL SCREEN
// ============================================================================
// UPDATE PATTERN: Optimistic Updates + Realtime Subscriptions
// - Optimistic: Eigene Änderungen sofort sichtbar (Status, Kommentare)
// - Realtime: Updates von anderen Users live empfangen
// - Rollback: Bei Fehler automatisch zum alten Zustand zurück
// ============================================================================

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Switch,
  Keyboard,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useFocusEffect } from '@react-navigation/native';

import {
  getOrderById,
  updateOrder,
  updateOrderStatus,
  addCommentToOrder,
  deleteComment,
} from '../services/crudOperations';
import { subscribeToOrders } from '../services/realtimeService';
import { uploadImage, replaceImage } from '../../../shared/utils/storage';
import { useAuth } from '../../auth/authContext';
import { usePermissions } from '../../auth/hooks/usePermissions';
import { useToast } from '../../../shared/components/Toast';
import logger from '../../../shared/utils/logger';
import DesignSystem from '../../../config/designSystem';
import { useTheme } from '../../../shared/themeContext';
import { useBranding } from '../../../shared/brandingContext';
import GlassHeader from '../../../shared/components/GlassHeader';
import { TimeUtils } from '../../../shared/utils/timeUtils';
import { useOrders } from '../../../shared/contexts/OrdersContext';

const OrderDetailScreen = ({ route, navigation }) => {
  const { orderId } = route.params;
  const { user, userRole } = useAuth();
  const { can } = usePermissions();
  const { showToast } = useToast();
  const { currentTheme } = useTheme();
  const { primaryColor } = useBranding();
  const { optimisticDeleteOrder } = useOrders();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);

  const [order, setOrder] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(true);

  const scrollViewRef = useRef(null);
  const commentInputRef = useRef(null);
  const scrollPositionRef = useRef(0);

  useFocusEffect(
    useCallback(() => {
      loadOrder();
    }, [orderId])
  );

  // Save scroll position to prevent auto-scroll to top
  const handleScroll = (event) => {
    scrollPositionRef.current = event.nativeEvent.contentOffset.y;
  };

  // ============================================================================
  // REALTIME SUBSCRIPTION - Live Updates von anderen Users
  // ============================================================================
  useEffect(() => {
    const unsubscribe = subscribeToOrders(
      null, // INSERT - nicht relevant für Detail-Screen
      (updatedOrder) => {
        // UPDATE - Nur aktualisieren wenn es unsere Order ist
        if (updatedOrder.id === orderId) {
          logger.realtime('[Realtime] Order aktualisiert von anderem User:', updatedOrder.title);
          setOrder(updatedOrder);
        }
      },
      (deletedOrder) => {
        // DELETE - Order wurde gelöscht, zurück navigieren
        if (deletedOrder.id === orderId) {
          logger.realtime('[Realtime] Order gelöscht');
          showToast({ message: 'Diese Order wurde gelöscht', type: 'info' });
          navigation.goBack();
        }
      }
    );

    return () => unsubscribe();
  }, [orderId]);

  const loadOrder = async () => {
    try {
      setLoading(true);
      const data = await getOrderById(orderId);
      setOrder(data);
    } catch (error) {
      logger.error('Error loading order:', error);
      Alert.alert('Fehler', 'Auftrag konnte nicht geladen werden');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateOrder = async (updates) => {
    // ============================================================================
    // OPTIMISTIC UPDATE - Änderungen sofort anzeigen
    // ============================================================================
    const oldOrder = { ...order };

    // Sofort UI updaten
    setOrder(prev => ({
      ...prev,
      ...updates,
      updated_at: new Date().toISOString(),
    }));

    logger.optimistic('[Optimistic] Order-Felder sofort aktualisiert');

    // API Call im Hintergrund
    const result = await updateOrder(orderId, updates);

    if (!result.success) {
      // ❌ Fehler: Rollback
      logger.orders('❌ [Rollback] Update fehlgeschlagen');
      setOrder(oldOrder);
      Alert.alert('Fehler', result.error || 'Änderungen konnten nicht gespeichert werden');
    } else {
      // ✅ Erfolg: Server-Daten übernehmen
      logger.orders('✅ [Confirmed] Update bestätigt');
      setOrder(result.data);
    }
  };

  // Status-Übersetzung für deutsche Anzeige
  const getStatusLabel = (status) => {
    const statusLabels = {
      open: 'Offen',
      done: 'Erledigt',
      archived: 'Archiviert',
    };
    return statusLabels[status] || status;
  };

  const handleStatusChange = async (newStatus) => {
    // Prüfe Berechtigung
    if (userRole === 'employee' && !order.editable_by_assigned) {
      Alert.alert(
        'Keine Berechtigung',
        'Nur Admins können den Status ändern. Der Admin kann dir jedoch Bearbeitungsrechte erteilen.'
      );
      return;
    }

    if (userRole === 'employee' && !order.assigned_to?.includes(user.id)) {
      Alert.alert(
        'Keine Berechtigung',
        'Du bist diesem Auftrag nicht zugewiesen.'
      );
      return;
    }

    // ============================================================================
    // OPTIMISTIC UPDATE - Sofort UI aktualisieren
    // ============================================================================
    const oldStatus = order.status;
    const oldNotes = order.notes;

    // Erstelle Status-Change-Note optimistisch (mit deutschen Status-Begriffen)
    const optimisticNote = {
      id: `temp_${Date.now()}`,
      type: 'status_change',
      text: `Status geändert: ${getStatusLabel(oldStatus)} → ${getStatusLabel(newStatus)}`,
      author: `${user.first_name} ${user.last_name}`,
      author_id: user.id,
      timestamp: new Date().toISOString(),
      old_status: oldStatus,
      new_status: newStatus,
    };

    // Sofort UI updaten (BEVOR API antwortet)
    setOrder(prev => ({
      ...prev,
      status: newStatus,
      notes: [...(prev.notes || []), optimisticNote],
      status_changed_by: user.id,
      status_changed_at: new Date().toISOString(),
    }));

    logger.optimistic('[Optimistic] Status sofort geändert:', newStatus);

    // Zeige Toast sofort
    showToast({
      message: newStatus === 'done' ? 'Auftrag erledigt!' : 'Status auf Offen gesetzt',
      type: 'success',
    });

    // API Call im Hintergrund
    const result = await updateOrderStatus(orderId, newStatus);

    if (!result.success) {
      // ❌ Fehler: Rollback zum alten Zustand
      logger.orders('❌ [Rollback] Status-Änderung fehlgeschlagen');
      setOrder(prev => ({
        ...prev,
        status: oldStatus,
        notes: oldNotes,
      }));
      showToast({
        message: result.error || 'Status konnte nicht geändert werden',
        type: 'error',
      });
    } else {
      // ✅ Erfolg: Server-Daten übernehmen (für korrekte note ID)
      logger.orders('✅ [Confirmed] Status-Änderung bestätigt');
      setOrder(result.data);
    }
  };

  const handleAddComment = async () => {
    if (!commentText.trim()) return;

    // ============================================================================
    // OPTIMISTIC UPDATE - Kommentar sofort anzeigen
    // ============================================================================
    const optimisticComment = {
      id: `temp_${Date.now()}`,
      type: 'comment',
      text: commentText.trim(),
      author: `${user.first_name} ${user.last_name}`,
      author_id: user.id,
      timestamp: new Date().toISOString(),
    };

    const oldNotes = order.notes;

    // Sofort UI updaten
    setOrder(prev => ({
      ...prev,
      notes: [...(prev.notes || []), optimisticComment],
    }));

    // Input sofort leeren (besseres UX)
    const commentToSend = commentText.trim();
    setCommentText('');

    logger.optimistic('[Optimistic] Kommentar sofort angezeigt');

    // API Call im Hintergrund
    const result = await addCommentToOrder(orderId, commentToSend);

    if (!result.success) {
      // ❌ Fehler: Rollback
      logger.orders('❌ [Rollback] Kommentar konnte nicht gespeichert werden');
      setOrder(prev => ({
        ...prev,
        notes: oldNotes,
      }));
      setCommentText(commentToSend); // Text wiederherstellen
      showToast({
        message: result.error || 'Kommentar konnte nicht gespeichert werden',
        type: 'error',
      });
    } else {
      // ✅ Erfolg: Server-Daten übernehmen (für korrekte comment ID)
      logger.orders('✅ [Confirmed] Kommentar gespeichert');
      setOrder(result.data);
    }
  };

  const handleDeleteComment = async (commentId, authorId) => {
    // Ersteller, Admin oder Co-Admin mit Permission können löschen
    const canDelete = user.id === authorId || userRole === 'admin' || (userRole === 'co-admin' && can('deleteComments'));

    logger.orders('🗑️ [Delete Comment] canDelete:', canDelete, '| userRole:', userRole, '| isOwnComment:', user.id === authorId);

    if (!canDelete) {
      Alert.alert('Keine Berechtigung', 'Du kannst nur deine eigenen Kommentare löschen');
      return;
    }

    Alert.alert(
      'Kommentar löschen',
      'Möchtest du diesen Kommentar wirklich löschen?',
      [
        { text: 'Abbrechen', style: 'cancel' },
        {
          text: 'Löschen',
          style: 'destructive',
          onPress: async () => {
            // ============================================================================
            // OPTIMISTIC UPDATE - Kommentar sofort entfernen
            // ============================================================================
            const oldNotes = order.notes;

            // Sofort aus UI entfernen
            setOrder(prev => ({
              ...prev,
              notes: (prev.notes || []).filter(note => note.id !== commentId),
            }));

            logger.optimistic('[Optimistic] Kommentar sofort gelöscht');

            // API Call im Hintergrund
            const result = await deleteComment(orderId, commentId);

            if (!result.success) {
              // ❌ Fehler: Rollback
              logger.orders('❌ [Rollback] Kommentar konnte nicht gelöscht werden');
              setOrder(prev => ({
                ...prev,
                notes: oldNotes,
              }));
              Alert.alert('Fehler', result.error || 'Kommentar konnte nicht gelöscht werden');
            } else {
              // ✅ Erfolg: Server-Daten übernehmen
              logger.orders('✅ [Confirmed] Kommentar gelöscht');
              setOrder(result.data);
            }
          },
        },
      ]
    );
  };

  const handleDeleteOrder = () => {
    Alert.alert(
      'Rezept löschen',
      `Möchtest du das Rezept "${order.title}" wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.`,
      [
        { text: 'Abbrechen', style: 'cancel' },
        {
          text: 'Löschen',
          style: 'destructive',
          onPress: async () => {
            // Optimistic delete - Order verschwindet sofort aus allen Screens
            const result = await optimisticDeleteOrder(orderId);
            if (result.success) {
              showToast({ message: 'Order gelöscht', type: 'success' });
              navigation.goBack();
            } else {
              Alert.alert('Fehler', result.error?.message || 'Order konnte nicht gelöscht werden');
            }
          },
        },
      ]
    );
  };

  const handleImagePick = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.8,
    });

    if (!result.canceled) {
      try {
        const uploadOptions = {
          companyId: user.company_id,
          orderId: orderId,
        };

        const imageUrl = order.image_url
          ? await replaceImage(order.image_url, result.assets[0].uri, 'order-images', uploadOptions)
          : await uploadImage(result.assets[0].uri, 'order-images', uploadOptions);

        await handleUpdateOrder({ image_url: imageUrl });
      } catch (error) {
        Alert.alert('Fehler', 'Bild konnte nicht hochgeladen werden');
      }
    }
  };

  if (loading || !order) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Lade Auftrag...</Text>
      </View>
    );
  }

  const canEdit =
    userRole === 'admin' ||
    (userRole === 'co-admin' && can('editOrders')) ||
    (userRole === 'employee' && order.editable_by_assigned && order.assigned_to?.includes(user.id));
  const canDelete = userRole === 'admin' || (userRole === 'co-admin' && can('deleteOrders'));

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* GLASS HEADER */}
      <GlassHeader
        title="Auftrag"
        rightAction={
          (canEdit || canDelete) ? (
            <View style={styles.headerActions}>
              {canDelete && (
                <TouchableOpacity onPress={handleDeleteOrder} style={styles.headerButton}>
                  <MaterialCommunityIcons name="delete" size={24} color={currentTheme.colors.danger} />
                </TouchableOpacity>
              )}
              {canEdit && (
                <TouchableOpacity
                  onPress={() => navigation.navigate('EditOrder', { orderId: order.id })}
                  style={styles.headerButton}
                >
                  <MaterialCommunityIcons name="cog" size={24} color={currentTheme.colors.text} />
                </TouchableOpacity>
              )}
            </View>
          ) : null
        }
      />

      <KeyboardAwareScrollView
        ref={scrollViewRef}
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        enableOnAndroid={true}
        extraScrollHeight={Platform.OS === 'ios' ? 150 : 200}
        keyboardShouldPersistTaps="handled"
        enableResetScrollToCoords={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
          {/* IMAGE */}
          {order.image_url ? (
            <TouchableOpacity onPress={canEdit ? handleImagePick : null} disabled={!canEdit} style={styles.imageContainer}>
              <Image
                source={{ uri: order.image_url }}
                style={styles.image}
                resizeMode="cover"
              />
              {canEdit && (
                <View style={styles.imageOverlay}>
                  <MaterialCommunityIcons name="camera" size={32} color="#FFFFFF" />
                </View>
              )}
            </TouchableOpacity>
          ) : canEdit ? (
            <TouchableOpacity style={styles.imagePlaceholder} onPress={handleImagePick}>
              <MaterialCommunityIcons name="image-plus" size={48} color={currentTheme.colors.textTertiary} />
              <Text style={styles.imagePlaceholderText}>Bild hinzufügen</Text>
            </TouchableOpacity>
          ) : null}

          {/* TITLE */}
          <Section label="Titel" theme={currentTheme}>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={order.title}
                onChangeText={(text) => handleUpdateOrder({ title: text })}
                placeholder="Titel eingeben"
              />
            ) : (
              <Text style={styles.value}>{order.title}</Text>
            )}
          </Section>

          {/* CATEGORY */}
          <Section label="Kategorie" theme={currentTheme}>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={order.category || ''}
                onChangeText={(text) => handleUpdateOrder({ category: text })}
                placeholder="z.B. Autowäsche"
              />
            ) : (
              <Text style={styles.value}>{order.category || '-'}</Text>
            )}
          </Section>

          {/* DESCRIPTION */}
          <Section label="Beschreibung" theme={currentTheme}>
            {isEditing ? (
              <TextInput
                style={[styles.input, styles.textArea]}
                value={order.description || ''}
                onChangeText={(text) => handleUpdateOrder({ description: text })}
                placeholder="Beschreibung eingeben"
                multiline
                numberOfLines={4}
              />
            ) : (
              <Text style={styles.value}>{order.description || '-'}</Text>
            )}
          </Section>

          {/* ADDITIONAL TEXT 1 */}
          <Section label="Textfeld 1" theme={currentTheme}>
            {isEditing ? (
              <TextInput
                style={[styles.input, styles.textArea]}
                value={order.additional_text || ''}
                onChangeText={(text) => handleUpdateOrder({ additional_text: text })}
                placeholder="Zusatzinformationen"
                multiline
                numberOfLines={3}
              />
            ) : (
              <Text style={styles.value}>{order.additional_text || '-'}</Text>
            )}
          </Section>

          {/* CUSTOMER NAME */}
          <Section label="Kundenname" theme={currentTheme}>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={order.customer_name || ''}
                onChangeText={(text) => handleUpdateOrder({ customer_name: text })}
                placeholder="Kundenname eingeben"
              />
            ) : (
              <Text style={styles.value}>{order.customer_name || '-'}</Text>
            )}
          </Section>

          {/* LOCATION */}
          <Section label="Ort" theme={currentTheme}>
            {isEditing ? (
              <TextInput
                style={styles.input}
                value={order.location || ''}
                onChangeText={(text) => handleUpdateOrder({ location: text })}
                placeholder="Ort eingeben"
              />
            ) : (
              <Text style={styles.value}>{order.location || '-'}</Text>
            )}
          </Section>

          {/* PRIORITY */}
          <Section label="Priorität" theme={currentTheme}>
            <View style={styles.row}>
              {[1, 2, 3, 4].map((p) => (
                <TouchableOpacity
                  key={p}
                  style={[
                    styles.priorityButton,
                    order.priority === p && [
                      styles.priorityButtonActive,
                      { backgroundColor: getPriorityColor(p, true, currentTheme) },
                    ],
                  ]}
                  onPress={() => isEditing && handleUpdateOrder({ priority: p })}
                  disabled={!isEditing}
                >
                  <Text
                    style={[
                      styles.priorityButtonText,
                      order.priority === p && { color: '#FFFFFF' },
                    ]}
                  >
                    P{p}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </Section>

          {/* DUE DATE */}
          <Section label="Fälligkeitsdatum" theme={currentTheme}>
            <Text style={styles.value}>
              {order.due_date
                ? TimeUtils.formatDateTime(order.due_date)
                : '-'}
            </Text>
          </Section>

          {/* STATUS CHANGE */}
          <Section label="Status ändern" theme={currentTheme}>
            <View style={styles.statusButtons}>
              <TouchableOpacity
                style={[
                  styles.statusButton,
                  order.status === 'open' && styles.statusButtonOpen,
                ]}
                onPress={() => handleStatusChange('open')}
              >
                <MaterialCommunityIcons name="circle-outline" size={18} color="#FFFFFF" />
                <Text style={styles.statusButtonText}>Offen</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.statusButton,
                  order.status === 'done' && styles.statusButtonDone,
                ]}
                onPress={() => handleStatusChange('done')}
              >
                <MaterialCommunityIcons name="check-circle" size={18} color="#FFFFFF" />
                <Text style={styles.statusButtonText}>Erledigt</Text>
              </TouchableOpacity>
            </View>
          </Section>

          {/* COMMENTS */}
          <Section label="Kommentare" theme={currentTheme}>
            {canEdit && (
              <View style={styles.commentInputContainer}>
                <View style={styles.commentInput}>
                  <TextInput
                    ref={commentInputRef}
                    style={styles.commentTextInput}
                    placeholder="Kommentar hinzufügen..."
                    placeholderTextColor={currentTheme.colors.textTertiary}
                    selectionColor={primaryColor}
                    cursorColor={primaryColor}
                    underlineColorAndroid="transparent"
                    value={commentText}
                    onChangeText={setCommentText}
                    onFocus={() => {
                      setTimeout(() => {
                        if (commentInputRef.current && scrollViewRef.current) {
                          commentInputRef.current.measure((fx, fy, width, height, px, py) => {
                            const scrollResponder = scrollViewRef.current.getScrollResponder();
                            if (scrollResponder && scrollResponder.scrollTo) {
                              scrollResponder.scrollTo({
                                x: 0,
                                y: py - 100,
                                animated: true
                              });
                            }
                          });
                        }
                      }, 300);
                    }}
                    multiline
                  />
                  <TouchableOpacity
                    style={styles.commentSendButton}
                    onPress={handleAddComment}
                    disabled={!commentText.trim()}
                  >
                    <MaterialCommunityIcons
                      name="send"
                      size={24}
                      color={commentText.trim() ? primaryColor : currentTheme.colors.textTertiary}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            )}

            {order.notes && order.notes.length > 0 ? (
              order.notes.map((note) => (
                <View
                  key={note.id}
                  style={[
                    styles.comment,
                    note.type === 'status_change' && styles.commentStatus,
                  ]}
                >
                  <View style={styles.commentHeader}>
                    <View>
                      <Text style={styles.commentAuthor}>
                        {note.author || 'Unbekannt'}
                      </Text>
                      <Text style={styles.commentTime}>
                        {TimeUtils.formatDateTime(note.timestamp)}
                      </Text>
                    </View>
                    {(user.id === note.author_id ||
                      userRole === 'admin' ||
                      (userRole === 'co-admin' && can('deleteComments'))) && (
                      <TouchableOpacity
                        onPress={() => handleDeleteComment(note.id, note.author_id)}
                      >
                        <MaterialCommunityIcons
                          name="delete"
                          size={20}
                          color={currentTheme.colors.danger}
                        />
                      </TouchableOpacity>
                    )}
                  </View>
                  {note.type === 'status_change' ? (
                    <View style={styles.statusChangeContent}>
                      <MaterialCommunityIcons
                        name="information"
                        size={16}
                        color="#856404"
                      />
                      <Text style={styles.commentTextStatus}>{note.text}</Text>
                    </View>
                  ) : (
                    <Text style={styles.commentText}>{note.text}</Text>
                  )}
                </View>
              ))
            ) : (
              <Text style={styles.noComments}>Noch keine Kommentare</Text>
            )}
          </Section>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

// ============================================================================
// SECTION COMPONENT
// ============================================================================
const Section = ({ label, children, theme }) => {
  const sectionStyles = React.useMemo(() => createStyles(theme), [theme]);
  return (
    <View style={sectionStyles.section}>
      <Text style={sectionStyles.label}>{label}</Text>
      {children}
    </View>
  );
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================
const getPriorityColor = (priority, isActive, theme) => {
  const colors = {
    1: '#4CAF50',
    2: '#FFC107',
    3: '#FF9800',
    4: '#F44336',
  };
  return isActive ? colors[priority] : theme.colors.surfaceVariant;
};

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  keyboardAvoid: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.colors.background,
  },
  loadingText: {
    ...DesignSystem.typography.body,
    color: theme.colors.textTertiary,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: DesignSystem.spacing.xl,
    paddingVertical: DesignSystem.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  headerTitle: {
    ...DesignSystem.typography.h4,
    color: theme.colors.text,
  },
  headerActions: {
    flexDirection: 'row',
    gap: DesignSystem.spacing.md,
  },
  headerButton: {
    padding: 4,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: DesignSystem.spacing.xl,
    paddingBottom: 200,
  },
  imageContainer: {
    width: '100%',
    height: 200,
    borderRadius: DesignSystem.borderRadius.lg,
    overflow: 'hidden',
    marginBottom: DesignSystem.spacing.xl,
  },
  image: {
    width: '100%',
    height: 200,
  },
  imageOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    borderRadius: DesignSystem.borderRadius.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imagePlaceholder: {
    width: '100%',
    height: 200,
    borderRadius: DesignSystem.borderRadius.lg,
    backgroundColor: theme.colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: DesignSystem.spacing.xl,
    borderWidth: 2,
    borderColor: theme.colors.border,
    borderStyle: 'dashed',
  },
  imagePlaceholderText: {
    marginTop: DesignSystem.spacing.sm,
    ...DesignSystem.typography.bodySmall,
    color: theme.colors.textTertiary,
  },
  section: {
    backgroundColor: theme.colors.surface,
    padding: DesignSystem.spacing.lg,
    borderRadius: DesignSystem.borderRadius.lg,
    marginBottom: DesignSystem.spacing.lg,
  },
  label: {
    ...DesignSystem.typography.caption,
    fontWeight: '700',
    color: theme.colors.textTertiary,
    textTransform: 'uppercase',
    marginBottom: DesignSystem.spacing.sm,
    letterSpacing: 0.5,
  },
  value: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.sm,
  },
  input: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
    padding: DesignSystem.spacing.md,
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  priorityButton: {
    flex: 1,
    padding: DesignSystem.spacing.md,
    borderRadius: DesignSystem.borderRadius.md,
    alignItems: 'center',
    backgroundColor: theme.colors.surfaceVariant,
  },
  priorityButtonActive: {},
  priorityButtonText: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '600',
    color: theme.colors.text,
  },
  statusButtons: {
    flexDirection: 'row',
    gap: DesignSystem.spacing.md,
  },
  statusButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: DesignSystem.spacing.sm,
    padding: DesignSystem.spacing.lg,
    borderRadius: DesignSystem.borderRadius.md,
    backgroundColor: theme.colors.surfaceVariant,
  },
  statusButtonOpen: {
    backgroundColor: '#4CAF50',
  },
  statusButtonDone: {
    backgroundColor: theme.colors.textSecondary,
  },
  statusButtonText: {
    ...DesignSystem.typography.button,
    color: '#FFFFFF',
  },
  commentInputContainer: {
    marginBottom: DesignSystem.spacing.lg,
  },
  commentInput: {
    flexDirection: 'row',
    gap: DesignSystem.spacing.md,
  },
  commentTextInput: {
    flex: 1,
    padding: DesignSystem.spacing.md,
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    color: theme.colors.text, // Dark Mode: Weiß auf Schwarz, Light Mode: Schwarz auf Weiß
    minHeight: 50,
    ...DesignSystem.typography.body,
  },
  commentSendButton: {
    width: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  comment: {
    padding: DesignSystem.spacing.md,
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    marginBottom: DesignSystem.spacing.md,
  },
  commentStatus: {
    backgroundColor: '#FFF3CD',
  },
  commentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: DesignSystem.spacing.sm,
  },
  commentAuthor: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '600',
    color: theme.colors.text,
  },
  commentTime: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textTertiary,
    marginTop: 2,
  },
  commentText: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
  },
  statusChangeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.sm,
  },
  commentTextStatus: {
    ...DesignSystem.typography.bodySmall,
    color: '#856404',
    fontStyle: 'italic',
  },
  noComments: {
    ...DesignSystem.typography.body,
    color: theme.colors.textTertiary,
    textAlign: 'center',
    paddingVertical: DesignSystem.spacing.xl,
  },
});

// Enable Why Did You Render tracking
if (__DEV__) {
  OrderDetailScreen.whyDidYouRender = true;
}

export default OrderDetailScreen;