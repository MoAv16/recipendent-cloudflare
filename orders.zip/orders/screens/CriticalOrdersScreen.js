import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useAuth } from '../../auth/authContext';
import { getOrders, deleteOrder, updateOrderStatus } from '../services/crudOperations';
import { subscribeToOrders } from '../services/realtimeService';
import { useTheme } from '../../../shared/themeContext';
import GlassCard from '../../../shared/components/GlassCard';
import GlassButton from '../../../shared/components/GlassButton';
import { TimeUtils } from '../../../shared/utils/timeUtils';

export default function CriticalOrdersScreen({ navigation }) {
  const { user, company } = useAuth();

  const { currentTheme } = useTheme();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Nur beim ersten Mount laden - Realtime übernimmt danach alle Updates
  useEffect(() => {
    if (company?.id) {
      loadOrders();
    }
  }, []); // Keine Dependencies - nur einmalig laden!

  // Realtime Subscription - Live Updates ohne Reload
  useEffect(() => {
    const unsubscribe = subscribeToOrders(
      (newOrder) => {
        // Prüfe ob Order kritisch ist (due_date in naher Zukunft)
        const isCritical = checkIfCritical(newOrder);
        if (isCritical) {
          console.log('🔴 [Realtime] Kritischer Auftrag:', newOrder.title);
          setOrders(prev => [newOrder, ...prev]);
        }
      },
      (updatedOrder) => {
        const isCritical = checkIfCritical(updatedOrder);
        console.log('🔴 [Realtime] Auftrag aktualisiert:', updatedOrder.title, '| Critical:', isCritical);
        if (isCritical) {
          setOrders(prev => {
            const exists = prev.find(o => o.id === updatedOrder.id);
            if (exists) {
              return prev.map(o => o.id === updatedOrder.id ? updatedOrder : o);
            } else {
              return [updatedOrder, ...prev];
            }
          });
        } else {
          // Nicht mehr kritisch - aus Liste entfernen
          setOrders(prev => prev.filter(o => o.id !== updatedOrder.id));
        }
      },
      (deletedOrder) => {
        console.log('🔴 [Realtime] Auftrag gelöscht:', deletedOrder.id);
        setOrders(prev => prev.filter(o => o.id !== deletedOrder.id));
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []); // Keine Dependencies - Subscription bleibt aktiv

  // Helper: Prüft ob Order kritisch ist
  const checkIfCritical = (order) => {
    if (!order.due_date || order.status !== 'open') return false;
    return TimeUtils.isCritical(order.due_date, order.critical_timer || 2);
  };

  const loadOrders = async () => {
    try {
      setLoading(true);

      const data = await getOrders('open'); // Nur offene Orders
      // Filtere kritische Orders (due_date < critical_timer Stunden)
      const criticalOrders = (data || []).filter(checkIfCritical);
      setOrders(criticalOrders);
    } catch (error) {
      console.error('Fehler beim Laden der Aufträge:', error);
      Alert.alert('Fehler', 'Aufträge konnten nicht geladen werden');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus);
    } catch (error) {
      Alert.alert('Fehler', 'Status konnte nicht aktualisiert werden');
    }
  };

  const handleDeleteOrder = (orderId) => {
    Alert.alert(
      'Auftrag löschen?',
      'Diese Aktion kann nicht rückgängig gemacht werden',
      [
        { text: 'Abbrechen', onPress: () => {} },
        {
          text: 'Löschen',
          onPress: async () => {
            try {
              await deleteOrder(orderId);
            } catch (error) {
              Alert.alert('Fehler', 'Auftrag konnte nicht gelöscht werden');
            }
          },
          style: 'destructive',
        },
      ]
    );
  };

  const renderOrderItem = ({ item }) => (
    <GlassCard
      intensity={40}
      style={styles.orderCard}
      onPress={() => navigation.navigate('OrderDetail', { orderId: item.id })}
    >
      <View style={styles.orderHeader}>
        <Text
          style={styles.orderTitle}
          numberOfLines={1}
        >
          {item.title}
        </Text>
        <View style={styles.statusBadge}>
          <Text style={styles.statusText}>Kritisch</Text>
        </View>
      </View>

      <Text
        style={styles.orderDescription}
        numberOfLines={2}
      >
        {item.description}
      </Text>

      <View style={styles.orderFooter}>
        <Text style={styles.orderMeta}>
          Priorität: {item.priority || 'N/A'}
        </Text>
        {item.due_date && (
          <Text style={styles.orderMeta}>
            Frist: {TimeUtils.formatDateTime(item.due_date)}
          </Text>
        )}
      </View>

      {user?.role !== 'employee' && (
        <View style={styles.quickActions}>
          <GlassButton
            title="Bearbeiten"
            variant="primary"
            onPress={() => navigation.navigate('EditOrder', { orderId: item.id })}
            style={styles.actionButton}
            textStyle={styles.actionButtonText}
          />
          <GlassButton
            title="Löschen"
            variant="danger"
            onPress={() => handleDeleteOrder(item.id)}
            style={styles.actionButton}
            textStyle={styles.actionButtonText}
          />
        </View>
      )}
    </GlassCard>
  );

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, styles.centerContent]} edges={['top', 'left', 'right']}>
        <ActivityIndicator size="large" color="#dc3545" />
        <Text style={styles.loadingText}>
          Kritische Aufträge werden geladen...
        </Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <StatusBar style="auto" />

      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          Kritische Aufträge
        </Text>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{orders.length}</Text>
        </View>
      </View>

      <FlatList
        data={orders}
        renderItem={renderOrderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#dc3545']}
            tintColor="#dc3545"
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              Keine kritischen Aufträge
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },
  centerContent: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: theme.colors.textSecondary,
  },
  loadingTextDark: {
    color: theme.colors.textSecondary,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: theme.colors.surfaceVariant,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: theme.colors.text,
  },
  headerTitleDark: {
    color: theme.colors.text,
  },
  badge: {
    backgroundColor: '#dc3545',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  badgeText: {
    color: theme.colors.text,
    fontSize: 14,
    fontWeight: '600',
  },
  listContent: {
    padding: 16,
    flexGrow: 1,
    paddingBottom: 100,
  },
  orderCard: {
    backgroundColor: theme.colors.surfaceVariant,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#dc3545',
  },
  orderCardDark: {
    backgroundColor: theme.colors.surface,
    borderLeftColor: '#dc3545',
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  orderTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    flex: 1,
  },
  orderTitleDark: {
    color: theme.colors.text,
  },
  statusBadge: {
    backgroundColor: '#dc3545',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  statusText: {
    fontSize: 12,
    color: theme.colors.text,
    fontWeight: '600',
  },
  orderDescription: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: 8,
  },
  orderDescriptionDark: {
    color: theme.colors.textSecondary,
  },
  orderFooter: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  orderMeta: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  orderMetaDark: {
    color: theme.colors.textSecondary,
  },
  quickActions: {
    flexDirection: 'row',
    marginTop: 12,
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
  editButton: {
    backgroundColor: '#2196F3',
  },
  deleteButton: {
    backgroundColor: '#FF4444',
  },
  actionButtonText: {
    color: theme.colors.text,
    fontSize: 12,
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: theme.colors.textSecondary,
  },
});
