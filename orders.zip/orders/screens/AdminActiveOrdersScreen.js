import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useAuth } from '../../auth/authContext';
import { getOrders, deleteOrder, updateOrderStatus } from '../services/crudOperations';
import { subscribeToOrders } from '../services/realtimeService';
import { useTheme } from '../../../shared/themeContext';
import { useBranding } from '../../../shared/brandingContext';
import GlassCard from '../../../shared/components/GlassCard';
import GlassButton from '../../../shared/components/GlassButton';
import { TimeUtils } from '../../../shared/utils/timeUtils';

export default function AdminActiveOrdersScreen({ navigation }) {
  const { user, company } = useAuth();
  const { currentTheme } = useTheme();
  const { primaryColor } = useBranding();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Nur beim ersten Mount laden - Realtime übernimmt danach alle Updates
  useEffect(() => {
    if (company?.id) {
      loadOrders();
    }
  }, []); // Keine Dependencies - nur einmalig laden!

  // Realtime Subscription - Live Updates ohne Reload
  useEffect(() => {
    const unsubscribe = subscribeToOrders(
      (newOrder) => {
        // Nur offene Orders zur Liste hinzufügen
        if (newOrder.status === 'open') {
          console.log('🔴 [Realtime] Neuer Auftrag:', newOrder.title);
          setOrders(prev => [newOrder, ...prev]);
        }
      },
      (updatedOrder) => {
        console.log('🔴 [Realtime] Auftrag aktualisiert:', updatedOrder.title);
        if (updatedOrder.status === 'open') {
          // Order aktualisieren oder hinzufügen falls nicht in Liste
          setOrders(prev => {
            const exists = prev.find(o => o.id === updatedOrder.id);
            if (exists) {
              return prev.map(o => o.id === updatedOrder.id ? updatedOrder : o);
            } else {
              return [updatedOrder, ...prev];
            }
          });
        } else {
          // Order wurde auf completed gesetzt - aus Liste entfernen
          setOrders(prev => prev.filter(o => o.id !== updatedOrder.id));
        }
      },
      (deletedOrder) => {
        console.log('🔴 [Realtime] Auftrag gelöscht:', deletedOrder.id);
        setOrders(prev => prev.filter(o => o.id !== deletedOrder.id));
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []); // Keine Dependencies - Subscription bleibt aktiv

  const loadOrders = async () => {
    try {
      setLoading(true);

      const data = await getOrders('open'); // Nur offene Orders
      setOrders(data || []);
    } catch (error) {
      console.error('Fehler beim Laden der Aufträge:', error);
      Alert.alert('Fehler', 'Aufträge konnten nicht geladen werden');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus);
    } catch (error) {
      Alert.alert('Fehler', 'Status konnte nicht aktualisiert werden');
    }
  };

  const handleDeleteOrder = (orderId) => {
    Alert.alert(
      'Auftrag löschen?',
      'Diese Aktion kann nicht rückgängig gemacht werden',
      [
        { text: 'Abbrechen', onPress: () => {} },
        {
          text: 'Löschen',
          onPress: async () => {
            try {
              await deleteOrder(orderId);
            } catch (error) {
              Alert.alert('Fehler', 'Auftrag konnte nicht gelöscht werden');
            }
          },
          style: 'destructive',
        },
      ]
    );
  };

  const renderOrderItem = ({ item }) => (
    <GlassCard
      intensity={40}
      style={[styles.orderCard, { borderLeftColor: primaryColor }]}
      onPress={() => navigation.navigate('OrderDetail', { orderId: item.id })}
    >
      <View style={styles.orderHeader}>
        <Text
          style={styles.orderTitle}
          numberOfLines={1}
        >
          {item.title}
        </Text>
        <View
          style={[
            styles.statusBadge,
            {
              backgroundColor:
                item.status === 'critical'
                  ? '#FF4444'
                  : item.status === 'open'
                  ? '#4CAF50'
                  : '#999',
            },
          ]}
        >
          <Text style={styles.statusText}>
            {item.status === 'open' ? 'Offen' : item.status === 'completed' ? 'Fertig' : 'Kritisch'}
          </Text>
        </View>
      </View>

      <Text
        style={styles.orderDescription}
        numberOfLines={2}
      >
        {item.description}
      </Text>

      <View style={styles.orderFooter}>
        <Text style={styles.orderMeta}>
          Priorität: {item.priority || 'N/A'}
        </Text>
        {item.due_date && (
          <Text style={styles.orderMeta}>
            Frist: {TimeUtils.formatDateTime(item.due_date)}
          </Text>
        )}
      </View>

      {user?.role !== 'employee' && (
        <View style={styles.quickActions}>
          <GlassButton
            title="Bearbeiten"
            variant="primary"
            onPress={() => navigation.navigate('EditOrder', { orderId: item.id })}
            style={styles.actionButton}
            textStyle={styles.actionButtonText}
          />
          <GlassButton
            title="Löschen"
            variant="danger"
            onPress={() => handleDeleteOrder(item.id)}
            style={styles.actionButton}
            textStyle={styles.actionButtonText}
          />
        </View>
      )}
    </GlassCard>
  );

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, styles.centerContent]} edges={['top', 'left', 'right']}>
        <ActivityIndicator size="large" color={primaryColor} />
        <Text style={styles.loadingText}>
          Aufträge werden geladen...
        </Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <StatusBar style="auto" />

      <FlatList
        data={orders}
        renderItem={renderOrderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[primaryColor]}
            tintColor={primaryColor}
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              Keine Aufträge gefunden
            </Text>
          </View>
        }
      />

      {(user?.role === 'admin' || user?.role === 'co-admin') && (
        <TouchableOpacity
          style={[styles.fab, { backgroundColor: primaryColor }]}
          onPress={() => navigation.navigate('CreateOrder')}
        >
          <Text style={styles.fabText}>+</Text>
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
}

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },
  centerContent: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: theme.colors.textSecondary,
  },
  loadingTextDark: {
    color: theme.colors.textSecondary,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: theme.colors.surfaceVariant,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  filterContainerDark: {
    backgroundColor: theme.colors.surface,
    borderBottomColor: '#333',
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#e0e0e0',
  },
  filterButtonDark: {
    backgroundColor: '#333',
  },
  filterButtonActive: {
    backgroundColor: '#bc79e0',
  },
  filterButtonText: {
    fontSize: 14,
    color: theme.colors.textSecondary,
  },
  filterButtonTextActive: {
    color: theme.colors.text,
  },
  listContent: {
    padding: 16,
    flexGrow: 1,
    paddingBottom: 100,
  },
  orderCard: {
    backgroundColor: theme.colors.surfaceVariant,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderLeftWidth: 4,
  },
  orderCardDark: {
    backgroundColor: theme.colors.surface,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  orderTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.text,
    flex: 1,
  },
  orderTitleDark: {
    color: theme.colors.text,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  statusText: {
    fontSize: 12,
    color: theme.colors.text,
    fontWeight: '600',
  },
  orderDescription: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: 8,
  },
  orderDescriptionDark: {
    color: theme.colors.textSecondary,
  },
  orderFooter: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
  },
  orderMeta: {
    fontSize: 12,
    color: theme.colors.textSecondary,
  },
  orderMetaDark: {
    color: theme.colors.textSecondary,
  },
  quickActions: {
    flexDirection: 'row',
    marginTop: 12,
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
  editButton: {
    backgroundColor: '#2196F3',
  },
  deleteButton: {
    backgroundColor: '#FF4444',
  },
  actionButtonText: {
    color: theme.colors.text,
    fontSize: 12,
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: theme.colors.text, // Besserer Kontrast in Dark Mode
  },
  fab: {
    position: 'absolute',
    bottom: 90,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  fabText: {
    fontSize: 28,
    color: theme.colors.text,
    fontWeight: 'bold',
  },
});
