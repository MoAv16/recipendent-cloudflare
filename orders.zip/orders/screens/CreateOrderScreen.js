// ============================================================================
// RECIPENDENT APP - CREATE ORDER SCREEN (UNIFIED & MODERNIZED)
// ============================================================================

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import * as ImagePicker from 'expo-image-picker';

import { useAuth } from '../../auth/authContext';
import { useBranding } from "../../../shared/brandingContext";
import { useCompany } from '../../settings/CompanyContext';
import { useOrders } from '../../../shared/contexts/OrdersContext';
import { createOrder, getUsers } from '../services/crudOperations';
import { uploadImage } from '../../../shared/utils/storage';
import { useToast } from '../../../shared/components/Toast';
import CustomDateTimePicker from '../../../shared/components/DateTimePicker/CustomDateTimePicker';
import DesignSystem from '../../../config/designSystem';
import { useTheme } from '../../../shared/themeContext';
import GlassButton from '../../../shared/components/GlassButton';
import GlassInput from '../../../shared/components/GlassInput';
import GlassHeader from '../../../shared/components/GlassHeader';
import { TimeUtils } from '../../../shared/utils/timeUtils';

// Priority Info Texte
const PRIORITY_INFO = {
  1: 'Sehr wichtig!',
  2: 'Wichtig',
  3: 'Neutral',
  4: 'Weniger wichtig',
};

const PRIORITY_COLORS = {
  1: '#F44336', // Rot
  2: '#FF9800', // Orange
  3: '#FFC107', // Gelb
  4: '#4CAF50', // Grün
};

function CreateOrderScreen({ navigation, route }) {
  const { user } = useAuth();
  const { primaryColor } = useBranding();
  const { showToast } = useToast();
  const { optimisticCreateOrder } = useOrders();
  const { currentTheme } = useTheme();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);
  const folderId = route?.params?.folderId || null;
  const isSubmittingRef = React.useRef(false);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [additionalText, setAdditionalText] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [location, setLocation] = useState('');
  const [priority, setPriority] = useState(2);
  const [criticalTimer, setCriticalTimer] = useState(2);

  // Image Upload
  const [imageUri, setImageUri] = useState(null);

  // Date & Time (combined)
  const [dueDate, setDueDate] = useState(null);
  const [showDatePicker, setShowDatePicker] = useState(false);

  // Team Assignment
  const [employees, setEmployees] = useState([]);
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [assignToTeam, setAssignToTeam] = useState(true);
  const [editableByAssigned, setEditableByAssigned] = useState(false);

  // Loading
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    const users = await getUsers();
    setEmployees(users);
  };

  // ============================================================================
  // IMAGE UPLOAD
  // ============================================================================
  const handleImagePick = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.8,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        setImageUri(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Image picker error:', error);
      showToast({
        message: 'Fehler beim Öffnen der Galerie',
        type: 'error',
      });
    }
  };

  // ============================================================================
  // TEAM SELECTION
  // ============================================================================
  const toggleEmployeeSelection = (employeeId) => {
    if (selectedEmployees.includes(employeeId)) {
      setSelectedEmployees(selectedEmployees.filter((id) => id !== employeeId));
    } else {
      setSelectedEmployees([...selectedEmployees, employeeId]);
    }
  };

  const handleSelectAll = () => {
    if (selectedEmployees.length === employees.length) {
      setSelectedEmployees([]);
    } else {
      setSelectedEmployees(employees.map((e) => e.id));
    }
  };

  // ============================================================================
  // CREATE ORDER
  // ============================================================================
  const handleCreateOrder = async () => {
    // Prevent double-submit
    if (isSubmittingRef.current) {
      return;
    }

    if (!title.trim()) {
      showToast({
        message: 'Bitte einen Titel eingeben',
        type: 'error',
      });
      return;
    }

    isSubmittingRef.current = true;
    setLoading(true);

    // ============================================================================
    // OPTIMISTIC CREATE - Order erscheint sofort in Liste
    // ============================================================================
    
    // Zeige sofort Success-Feedback
    showToast({
      message: 'Auftrag wird erstellt...',
      type: 'success',
    });

    // Navigate back sofort (optimistisch)
    navigation.goBack();

    try {
      // 1. Upload image first (if selected) - im Hintergrund
      let imageUrl = null;
      if (imageUri) {
        try {
          imageUrl = await uploadImage(imageUri, 'order-images', {
            companyId: user.company_id,
          });
        } catch (error) {
          console.error('Image upload error:', error);
          // Continue without image
        }
      }

      // 2. Create order data
      const authorName = user.first_name && user.last_name
        ? `${user.first_name} ${user.last_name}`
        : 'Unbekannt';

      // Berechne automatisch den korrekten Status basierend auf Fälligkeit und Timer
      const calculatedStatus = TimeUtils.calculateOrderStatus(
        dueDate ? dueDate.toISOString() : null,
        criticalTimer,
        'open' // New orders start as 'open', but may be 'critical' immediately
      );

      const orderData = {
        title: title.trim(),
        category: category.trim() || null,
        description: description.trim(),
        additional_text: additionalText.trim() || null,
        customer_name: customerName.trim() || null,
        location: location.trim() || null,
        priority: priority,
        due_date: dueDate ? dueDate.toISOString() : null,
        critical_timer: criticalTimer,
        folder_id: folderId,
        assigned_to: assignToTeam ? employees.map((e) => e.id) : selectedEmployees,
        editable_by_assigned: editableByAssigned,
        image_url: imageUrl,
        company_id: user.company_id,
        author_id: user.id,
        author_name: authorName, // ✅ FIX: NOT NULL constraint
        status: calculatedStatus, // Auto-calculated based on due_date and critical_timer
      };

      // 3. Optimistic create (instant + background DB)
      const result = await optimisticCreateOrder(orderData);

      if (!result.success) {
        // Fehler: Zeige Toast
        showToast({
          message: result.error?.message || 'Fehler beim Erstellen',
          type: 'error',
        });
      }
    } catch (error) {
      showToast({
        message: 'Unerwarteter Fehler: ' + error.message,
        type: 'error',
      });
    } finally {
      setLoading(false);
      isSubmittingRef.current = false;
    }
  };

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* GLASS HEADER */}
        <GlassHeader
          title="Auftrag erstellen"
          icon="file-document-plus-outline"
          showBackButton={true}
        />

        <KeyboardAwareScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          enableOnAndroid={true}
          extraScrollHeight={20}
          keyboardShouldPersistTaps="handled"
        >
            {/* IMAGE UPLOAD */}
            {imageUri ? (
              <TouchableOpacity onPress={handleImagePick} style={styles.imageContainer}>
                <Image source={{ uri: imageUri }} style={styles.image} />
                <View style={styles.imageOverlay}>
                  <MaterialCommunityIcons name="camera" size={32} color="#FFFFFF" />
                  <Text style={styles.imageOverlayText}>Bild ändern</Text>
                </View>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity style={styles.imagePlaceholder} onPress={handleImagePick}>
                <MaterialCommunityIcons name="image-plus" size={48} color={currentTheme.colors.textTertiary} />
                <Text style={styles.imagePlaceholderText}>Bild hinzufügen (optional)</Text>
              </TouchableOpacity>
            )}

            {/* BASIC INFO */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Basis-Informationen</Text>

              <GlassInput
                label="Titel *"
                value={title}
                onChangeText={setTitle}
                placeholder="z.B. BMW 3er Außenreinigung"
              />

              <GlassInput
                label="Kategorie"
                value={category}
                onChangeText={setCategory}
                placeholder="z.B. Reinigung, Wartung..."
              />

              <GlassInput
                label="Beschreibung"
                value={description}
                onChangeText={setDescription}
                placeholder="Detaillierte Beschreibung..."
                multiline
                numberOfLines={6}
              />

              <GlassInput
                label="Notizen"
                value={additionalText}
                onChangeText={setAdditionalText}
                placeholder="Zusätzliche Informationen..."
              />

              <GlassInput
                label="Kundenname"
                value={customerName}
                onChangeText={setCustomerName}
                placeholder="z.B. Max Mustermann"
              />

              <GlassInput
                label="Ort"
                value={location}
                onChangeText={setLocation}
                placeholder="z.B. Halle 1 / Platz 3"
              />
            </View>

            {/* PRIORITY */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Priorität</Text>

              <View style={styles.priorityGrid}>
                {[1, 2, 3, 4].map((p) => (
                  <TouchableOpacity
                    key={p}
                    style={[
                      styles.priorityButton,
                      priority === p && [
                        styles.priorityButtonActive,
                        { borderColor: PRIORITY_COLORS[p] },
                      ],
                    ]}
                    onPress={() => setPriority(p)}
                  >
                    <View
                      style={[
                        styles.priorityCircle,
                        { backgroundColor: PRIORITY_COLORS[p] },
                      ]}
                    >
                      <Text style={styles.priorityNumber}>P{p}</Text>
                    </View>
                    <Text
                      style={[
                        styles.priorityInfo,
                        priority === p && styles.priorityInfoActive,
                      ]}
                    >
                      {PRIORITY_INFO[p]}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* DATE & TIME */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Fälligkeitsdatum</Text>

              <TouchableOpacity
                style={styles.datePickerButton}
                onPress={() => setShowDatePicker(true)}
                activeOpacity={0.7}
              >
                <MaterialCommunityIcons
                  name="calendar-clock"
                  size={24}
                  color={primaryColor}
                />
                <View style={styles.datePickerInfo}>
                  <Text style={styles.datePickerLabel}>Datum & Uhrzeit</Text>
                  <Text style={[styles.datePickerValue, !dueDate && styles.datePickerPlaceholder]}>
                    {dueDate
                      ? TimeUtils.formatDateTime(dueDate)
                      : 'Datum und Uhrzeit wählen'}
                  </Text>
                </View>
                {dueDate && (
                  <TouchableOpacity
                    onPress={() => setDueDate(null)}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <MaterialCommunityIcons
                      name="close-circle"
                      size={20}
                      color={currentTheme.colors.textSecondary}
                    />
                  </TouchableOpacity>
                )}
              </TouchableOpacity>

              <CustomDateTimePicker
                visible={showDatePicker}
                value={dueDate || new Date()}
                onConfirm={(date) => {
                  setDueDate(date);
                  setShowDatePicker(false);
                }}
                onCancel={() => setShowDatePicker(false)}
              />
            </View>

            {/* CRITICAL TIMER */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Kritischer Timer</Text>
              <Text style={styles.helperText}>
                Der Auftrag wird als kritisch markiert, wenn diese Anzahl an Stunden
                vor dem Fälligkeitsdatum erreicht ist
              </Text>

              <View style={styles.timerDisplay}>
                <View style={styles.timerValueContainer}>
                  <Text style={styles.timerValue}>{criticalTimer}</Text>
                  <Text style={styles.timerUnit}>Stunden</Text>
                </View>
              </View>

              <Slider
                style={styles.slider}
                minimumValue={0}
                maximumValue={48}
                step={1}
                value={criticalTimer}
                onValueChange={setCriticalTimer}
                minimumTrackTintColor={primaryColor}
                maximumTrackTintColor={currentTheme.colors.border}
                thumbTintColor={primaryColor}
              />

              <View style={styles.sliderLabels}>
                <Text style={styles.sliderLabel}>0h</Text>
                <Text style={styles.sliderLabel}>24h</Text>
                <Text style={styles.sliderLabel}>48h</Text>
              </View>
            </View>

            {/* TEAM ASSIGNMENT */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Zuweisung</Text>

              <TouchableOpacity
                style={styles.assignmentOption}
                onPress={() => setAssignToTeam(!assignToTeam)}
              >
                <View style={styles.assignmentLeft}>
                  <MaterialCommunityIcons
                    name={assignToTeam ? 'checkbox-marked' : 'checkbox-blank-outline'}
                    size={24}
                    color={primaryColor}
                  />
                  <Text style={styles.assignmentText}>Dem gesamten Team zuweisen</Text>
                </View>
              </TouchableOpacity>

              {!assignToTeam && (
                <View style={styles.employeeSelectionContainer}>
                  <View style={styles.employeeHeader}>
                    <Text style={styles.employeeHeaderText}>
                      {selectedEmployees.length} von {employees.length} ausgewählt
                    </Text>
                    <TouchableOpacity onPress={handleSelectAll}>
                      <Text style={[styles.selectAllButton, { color: primaryColor }]}>
                        {selectedEmployees.length === employees.length ? 'Alle abwählen' : 'Alle auswählen'}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View style={styles.employeeList}>
                    {employees.map((employee) => (
                      <TouchableOpacity
                        key={employee.id}
                        style={styles.employeeItem}
                        onPress={() => toggleEmployeeSelection(employee.id)}
                        activeOpacity={0.7}
                      >
                        <View style={styles.employeeInfo}>
                          <View
                            style={[
                              styles.employeeAvatar,
                              { backgroundColor: primaryColor + '20' },
                            ]}
                          >
                            <Text style={[styles.employeeInitials, { color: primaryColor }]}>
                              {employee.first_name[0]}{employee.last_name[0]}
                            </Text>
                          </View>
                          <Text style={styles.employeeName}>
                            {employee.first_name} {employee.last_name}
                          </Text>
                        </View>
                        <MaterialCommunityIcons
                          name={
                            selectedEmployees.includes(employee.id)
                              ? 'checkbox-marked'
                              : 'checkbox-blank-outline'
                          }
                          size={24}
                          color={
                            selectedEmployees.includes(employee.id)
                              ? primaryColor
                              : currentTheme.colors.textTertiary
                          }
                        />
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              <TouchableOpacity
                style={styles.assignmentOption}
                onPress={() => setEditableByAssigned(!editableByAssigned)}
              >
                <View style={styles.assignmentLeft}>
                  <MaterialCommunityIcons
                    name={editableByAssigned ? 'checkbox-marked' : 'checkbox-blank-outline'}
                    size={24}
                    color={primaryColor}
                  />
                  <Text style={styles.assignmentText}>
                    Zugewiesene dürfen bearbeiten
                  </Text>
                </View>
              </TouchableOpacity>
            </View>

            {/* CREATE BUTTON */}
            <GlassButton
              title="Auftrag erstellen"
              onPress={handleCreateOrder}
              variant="primary"
              loading={loading}
            />
        </KeyboardAwareScrollView>
      </SafeAreaView>
    </View>
  );
}

// Enable Why Did You Render tracking
if (__DEV__) {
  CreateOrderScreen.whyDidYouRender = true;
}

export default CreateOrderScreen;

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: DesignSystem.spacing.xl,
    paddingBottom: 100,
  },
  // Image Styles
  imageContainer: {
    width: '100%',
    height: 200,
    borderRadius: DesignSystem.borderRadius.lg,
    marginBottom: DesignSystem.spacing.xl,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: '100%',
    backgroundColor: theme.colors.surfaceVariant,
  },
  imageOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageOverlayText: {
    ...DesignSystem.typography.bodySmall,
    color: '#FFFFFF',
    marginTop: DesignSystem.spacing.xs,
  },
  imagePlaceholder: {
    width: '100%',
    height: 200,
    borderRadius: DesignSystem.borderRadius.lg,
    backgroundColor: theme.colors.surfaceVariant,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: DesignSystem.spacing.xl,
    borderWidth: 2,
    borderColor: theme.colors.border,
    borderStyle: 'dashed',
  },
  imagePlaceholderText: {
    marginTop: DesignSystem.spacing.sm,
    ...DesignSystem.typography.bodySmall,
    color: theme.colors.textTertiary,
  },
  section: {
    backgroundColor: theme.colors.surface,
    borderRadius: DesignSystem.borderRadius.lg,
    padding: DesignSystem.spacing.lg,
    marginBottom: DesignSystem.spacing.lg,
    ...DesignSystem.shadows.sm,
  },
  sectionTitle: {
    ...DesignSystem.typography.h4,
    color: theme.colors.text,
    marginBottom: DesignSystem.spacing.lg,
  },
  // Priority Styles
  priorityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: DesignSystem.spacing.md,
  },
  priorityButton: {
    width: '47%',
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    padding: DesignSystem.spacing.md,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  priorityButtonActive: {
    borderWidth: 2,
  },
  priorityCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: DesignSystem.spacing.sm,
  },
  priorityNumber: {
    ...DesignSystem.typography.h4,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  priorityInfo: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  priorityInfoActive: {
    color: theme.colors.text,
    fontWeight: '600',
  },
  // Helper Text
  helperText: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    marginBottom: DesignSystem.spacing.md,
  },
  // DateTimePicker Button Styles
  datePickerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.md,
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    paddingVertical: DesignSystem.spacing.md,
    paddingHorizontal: DesignSystem.spacing.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  datePickerInfo: {
    flex: 1,
  },
  datePickerLabel: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    marginBottom: 2,
  },
  datePickerValue: {
    ...DesignSystem.typography.body,
    fontWeight: '600',
    color: theme.colors.text,
  },
  datePickerPlaceholder: {
    color: theme.colors.textTertiary,
    fontWeight: '400',
  },
  // Critical Timer Styles
  timerDisplay: {
    alignItems: 'center',
    marginVertical: DesignSystem.spacing.md,
  },
  timerValueContainer: {
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.lg,
    paddingHorizontal: DesignSystem.spacing.xxxl,
    paddingVertical: DesignSystem.spacing.lg,
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  timerValue: {
    fontSize: 48,
    fontWeight: '700',
    color: theme.colors.text,
    textAlign: 'center',
  },
  timerUnit: {
    ...DesignSystem.typography.body,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginTop: DesignSystem.spacing.xs,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  sliderLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: DesignSystem.spacing.sm,
  },
  sliderLabel: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
  },
  // Assignment Styles
  assignmentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: DesignSystem.spacing.md,
  },
  assignmentLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.md,
  },
  assignmentText: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
  },
  employeeSelectionContainer: {
    marginTop: DesignSystem.spacing.sm,
    marginBottom: DesignSystem.spacing.md,
  },
  employeeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: DesignSystem.spacing.sm,
    paddingHorizontal: DesignSystem.spacing.sm,
  },
  employeeHeaderText: {
    ...DesignSystem.typography.bodySmall,
    color: theme.colors.textSecondary,
  },
  selectAllButton: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '600',
  },
  employeeList: {
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    overflow: 'hidden',
  },
  employeeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: DesignSystem.spacing.md,
    paddingHorizontal: DesignSystem.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  employeeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.md,
  },
  employeeAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  employeeInitials: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '700',
  },
  employeeName: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
  },
});
