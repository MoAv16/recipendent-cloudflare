// ============================================================================
// RECIPENDENT APP - EDIT ORDER SCREEN (UNIFIED & MODERNIZED)
// ============================================================================

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';

import { useAuth } from '../../auth/authContext';
import { useBranding } from "../../../shared/brandingContext";
import { useCompany } from '../../settings/CompanyContext';
import { useOrders } from '../../../shared/contexts/OrdersContext';
import { getOrderById, updateOrder, getUsers } from '../services/crudOperations';
import { useToast } from '../../../shared/components/Toast';
import { useTheme } from '../../../shared/themeContext';
import CustomDateTimePicker from '../../../shared/components/DateTimePicker/CustomDateTimePicker';
import DesignSystem from '../../../config/designSystem';
import GlassButton from '../../../shared/components/GlassButton';
import GlassInput from '../../../shared/components/GlassInput';
import GlassHeader from '../../../shared/components/GlassHeader';
import { TimeUtils } from '../../../shared/utils/timeUtils';

// Priority Info Texte
const PRIORITY_INFO = {
  1: 'Sehr wichtig!',
  2: 'Wichtig',
  3: 'Neutral',
  4: 'Weniger wichtig',
};

const PRIORITY_COLORS = {
  1: '#F44336', // Rot
  2: '#FF9800', // Orange
  3: '#FFC107', // Gelb
  4: '#4CAF50', // Grün
};

function EditOrderScreen({ navigation, route }) {
  const { orderId } = route.params;
  const { user } = useAuth();
  const { primaryColor } = useBranding();
  const { showToast } = useToast();
  const { optimisticUpdateOrder } = useOrders();
  const isSubmittingRef = React.useRef(false);

  // Form State
  const { currentTheme } = useTheme();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [additionalText, setAdditionalText] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [location, setLocation] = useState('');
  const [priority, setPriority] = useState(2);
  const [criticalTimer, setCriticalTimer] = useState(2);

  // Date & Time (combined)
  const [dueDate, setDueDate] = useState(null);
  const [showDatePicker, setShowDatePicker] = useState(false);

  // Team Assignment
  const [employees, setEmployees] = useState([]);
  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [assignToTeam, setAssignToTeam] = useState(true);
  const [editableByAssigned, setEditableByAssigned] = useState(false);

  // Loading
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadOrderAndEmployees();
  }, [orderId]);

  const loadOrderAndEmployees = async () => {
    try {
      setLoading(true);

      // Load Order
      const order = await getOrderById(orderId);
      if (!order) {
        showToast({
          message: 'Auftrag nicht gefunden',
          type: 'error',
        });
        navigation.goBack();
        return;
      }

      // Set Order Data
      setTitle(order.title || '');
      setCategory(order.category || '');
      setDescription(order.description || '');
      setAdditionalText(order.additional_text || '');
      setCustomerName(order.customer_name || '');
      setLocation(order.location || '');
      setPriority(order.priority || 2);
      setCriticalTimer(order.critical_timer || 2);
      setEditableByAssigned(order.editable_by_assigned || false);

      // Parse due date
      if (order.due_date) {
        setDueDate(new Date(order.due_date));
      }

      // Load Team Members
      const users = await getUsers();
      setEmployees(users);

      // Set assignment
      const assigned = order.assigned_to || [];
      setSelectedEmployees(assigned);

      // Check if assigned to all team
      if (assigned.length === users.length) {
        setAssignToTeam(true);
      } else if (assigned.length > 0) {
        setAssignToTeam(false);
      }
    } catch (error) {
      console.error('Load order error:', error);
      showToast({
        message: 'Fehler beim Laden des Auftrags',
        type: 'error',
      });
    } finally {
      setLoading(false);
    }
  };

  // ============================================================================
  // TEAM SELECTION
  // ============================================================================
  const toggleEmployeeSelection = (employeeId) => {
    if (selectedEmployees.includes(employeeId)) {
      setSelectedEmployees(selectedEmployees.filter((id) => id !== employeeId));
    } else {
      setSelectedEmployees([...selectedEmployees, employeeId]);
    }
  };

  const handleSelectAll = () => {
    if (selectedEmployees.length === employees.length) {
      setSelectedEmployees([]);
    } else {
      setSelectedEmployees(employees.map((e) => e.id));
    }
  };

  // ============================================================================
  // UPDATE ORDER
  // ============================================================================
  const handleUpdateOrder = async () => {
    // Prevent double-submit
    if (isSubmittingRef.current) {
      return;
    }

    if (!title.trim()) {
      showToast({
        message: 'Bitte einen Titel eingeben',
        type: 'error',
      });
      return;
    }

    isSubmittingRef.current = true;
    setSaving(true);

    // ============================================================================
    // OPTIMISTIC UPDATE - Änderungen sofort sichtbar
    // ============================================================================

    // Berechne automatisch den korrekten Status basierend auf Fälligkeit und Timer
    const calculatedStatus = TimeUtils.calculateOrderStatus(
      dueDate ? dueDate.toISOString() : null,
      criticalTimer,
      'open' // Assuming current status is 'open' - will be preserved if 'done'
    );

    const updates = {
      title: title.trim(),
      category: category.trim() || null,
      description: description.trim(),
      additional_text: additionalText.trim() || null,
      customer_name: customerName.trim() || null,
      location: location.trim() || null,
      priority: priority,
      due_date: dueDate ? dueDate.toISOString() : null,
      critical_timer: criticalTimer,
      status: calculatedStatus, // Auto-update status
      assigned_to: assignToTeam ? employees.map((e) => e.id) : selectedEmployees,
      editable_by_assigned: editableByAssigned,
    };

    // Zeige sofort Success & navigate back
    showToast({
      message: 'Auftrag wird aktualisiert...',
      type: 'success',
    });
    navigation.goBack();

    // Optimistic update (instant + background DB)
    const result = await optimisticUpdateOrder(orderId, updates);

    if (!result.success) {
      // Fehler: Zeige Toast (User ist schon zurück navigiert)
      showToast({
        message: result.error?.message || 'Fehler beim Aktualisieren',
        type: 'error',
      });
    }

    setSaving(false);
    isSubmittingRef.current = false;
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={primaryColor} />
        <Text style={styles.loadingText}>Lade Auftrag...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* GLASS HEADER */}
        <GlassHeader
          title="Auftrag bearbeiten"
          icon="file-document-edit-outline"
          showBackButton={true}
        />

        <KeyboardAwareScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          enableOnAndroid={true}
          extraScrollHeight={20}
          keyboardShouldPersistTaps="handled"
        >
            {/* BASIC INFO */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Basis-Informationen</Text>

              <GlassInput
                label="Titel *"
                value={title}
                onChangeText={setTitle}
                placeholder="z.B. BMW 3er Außenreinigung"
              />

              <GlassInput
                label="Kategorie"
                value={category}
                onChangeText={setCategory}
                placeholder="z.B. Reinigung, Wartung..."
              />

              <GlassInput
                label="Beschreibung"
                value={description}
                onChangeText={setDescription}
                placeholder="Detaillierte Beschreibung..."
                multiline
                numberOfLines={6}
              />

              <GlassInput
                label="Notizen"
                value={additionalText}
                onChangeText={setAdditionalText}
                placeholder="Zusätzliche Informationen..."
              />

              <GlassInput
                label="Kundenname"
                value={customerName}
                onChangeText={setCustomerName}
                placeholder="z.B. Max Mustermann"
              />

              <GlassInput
                label="Ort"
                value={location}
                onChangeText={setLocation}
                placeholder="z.B. Halle 1 / Platz 3"
              />
            </View>

            {/* PRIORITY */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Priorität</Text>

              <View style={styles.priorityGrid}>
                {[1, 2, 3, 4].map((p) => (
                  <TouchableOpacity
                    key={p}
                    style={[
                      styles.priorityButton,
                      priority === p && [
                        styles.priorityButtonActive,
                        { borderColor: PRIORITY_COLORS[p] },
                      ],
                    ]}
                    onPress={() => setPriority(p)}
                  >
                    <View
                      style={[
                        styles.priorityCircle,
                        { backgroundColor: PRIORITY_COLORS[p] },
                      ]}
                    >
                      <Text style={styles.priorityNumber}>P{p}</Text>
                    </View>
                    <Text
                      style={[
                        styles.priorityInfo,
                        priority === p && styles.priorityInfoActive,
                      ]}
                    >
                      {PRIORITY_INFO[p]}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* DATE & TIME */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Fälligkeitsdatum</Text>

              <TouchableOpacity
                style={styles.datePickerButton}
                onPress={() => setShowDatePicker(true)}
                activeOpacity={0.7}
              >
                <MaterialCommunityIcons
                  name="calendar-clock"
                  size={24}
                  color={primaryColor}
                />
                <View style={styles.datePickerInfo}>
                  <Text style={styles.datePickerLabel}>Datum & Uhrzeit</Text>
                  <Text style={[styles.datePickerValue, !dueDate && styles.datePickerPlaceholder]}>
                    {dueDate
                      ? TimeUtils.formatDateTime(dueDate)
                      : 'Datum und Uhrzeit wählen'}
                  </Text>
                </View>
                {dueDate && (
                  <TouchableOpacity
                    onPress={() => setDueDate(null)}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <MaterialCommunityIcons
                      name="close-circle"
                      size={20}
                      color={DesignSystem.colors.textSecondary}
                    />
                  </TouchableOpacity>
                )}
              </TouchableOpacity>

              <CustomDateTimePicker
                visible={showDatePicker}
                value={dueDate || new Date()}
                onConfirm={(date) => {
                  setDueDate(date);
                  setShowDatePicker(false);
                }}
                onCancel={() => setShowDatePicker(false)}
              />
            </View>

            {/* CRITICAL TIMER */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Kritischer Timer</Text>
              <Text style={styles.helperText}>
                Der Auftrag wird als kritisch markiert, wenn diese Anzahl an Stunden
                vor dem Fälligkeitsdatum erreicht ist
              </Text>

              <View style={styles.timerDisplay}>
                <View style={styles.timerValueContainer}>
                  <Text style={styles.timerValue}>{criticalTimer}</Text>
                  <Text style={styles.timerUnit}>Stunden</Text>
                </View>
              </View>

              <Slider
                style={styles.slider}
                minimumValue={0}
                maximumValue={48}
                step={1}
                value={criticalTimer}
                onValueChange={setCriticalTimer}
                minimumTrackTintColor={primaryColor}
                maximumTrackTintColor={DesignSystem.colors.border}
                thumbTintColor={primaryColor}
              />

              <View style={styles.sliderLabels}>
                <Text style={styles.sliderLabel}>0h</Text>
                <Text style={styles.sliderLabel}>24h</Text>
                <Text style={styles.sliderLabel}>48h</Text>
              </View>
            </View>

            {/* TEAM ASSIGNMENT */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Zuweisung</Text>

              <TouchableOpacity
                style={styles.assignmentOption}
                onPress={() => setAssignToTeam(!assignToTeam)}
              >
                <View style={styles.assignmentLeft}>
                  <MaterialCommunityIcons
                    name={assignToTeam ? 'checkbox-marked' : 'checkbox-blank-outline'}
                    size={24}
                    color={primaryColor}
                  />
                  <Text style={styles.assignmentText}>Dem gesamten Team zuweisen</Text>
                </View>
              </TouchableOpacity>

              {!assignToTeam && (
                <View style={styles.employeeSelectionContainer}>
                  <View style={styles.employeeHeader}>
                    <Text style={styles.employeeHeaderText}>
                      {selectedEmployees.length} von {employees.length} ausgewählt
                    </Text>
                    <TouchableOpacity onPress={handleSelectAll}>
                      <Text style={[styles.selectAllButton, { color: primaryColor }]}>
                        {selectedEmployees.length === employees.length ? 'Alle abwählen' : 'Alle auswählen'}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  <View style={styles.employeeList}>
                    {employees.map((employee) => (
                      <TouchableOpacity
                        key={employee.id}
                        style={styles.employeeItem}
                        onPress={() => toggleEmployeeSelection(employee.id)}
                        activeOpacity={0.7}
                      >
                        <View style={styles.employeeInfo}>
                          <View
                            style={[
                              styles.employeeAvatar,
                              { backgroundColor: primaryColor + '20' },
                            ]}
                          >
                            <Text style={[styles.employeeInitials, { color: primaryColor }]}>
                              {employee.first_name[0]}{employee.last_name[0]}
                            </Text>
                          </View>
                          <Text style={styles.employeeName}>
                            {employee.first_name} {employee.last_name}
                          </Text>
                        </View>
                        <MaterialCommunityIcons
                          name={
                            selectedEmployees.includes(employee.id)
                              ? 'checkbox-marked'
                              : 'checkbox-blank-outline'
                          }
                          size={24}
                          color={
                            selectedEmployees.includes(employee.id)
                              ? primaryColor
                              : DesignSystem.colors.textTertiary
                          }
                        />
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              )}

              <TouchableOpacity
                style={styles.assignmentOption}
                onPress={() => setEditableByAssigned(!editableByAssigned)}
              >
                <View style={styles.assignmentLeft}>
                  <MaterialCommunityIcons
                    name={editableByAssigned ? 'checkbox-marked' : 'checkbox-blank-outline'}
                    size={24}
                    color={primaryColor}
                  />
                  <Text style={styles.assignmentText}>
                    Zugewiesene dürfen bearbeiten
                  </Text>
                </View>
              </TouchableOpacity>
            </View>

            {/* SAVE BUTTON */}
            <GlassButton
              title="Änderungen speichern"
              onPress={handleUpdateOrder}
              variant="primary"
              loading={saving}
            />
        </KeyboardAwareScrollView>
      </SafeAreaView>
    </View>
  );
}

// Enable Why Did You Render tracking
if (__DEV__) {
  EditOrderScreen.whyDidYouRender = true;
}

export default EditOrderScreen;

const createStyles = (theme) => StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  safeArea: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: theme.colors.background,
  },
  loadingText: {
    marginTop: DesignSystem.spacing.md,
    ...DesignSystem.typography.body,
    color: theme.colors.textSecondary,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: DesignSystem.spacing.xl,
    paddingBottom: 100,
  },
  section: {
    backgroundColor: theme.colors.surface,
    borderRadius: DesignSystem.borderRadius.lg,
    padding: DesignSystem.spacing.lg,
    marginBottom: DesignSystem.spacing.lg,
    ...DesignSystem.shadows.sm,
  },
  sectionTitle: {
    ...DesignSystem.typography.h4,
    color: theme.colors.text,
    marginBottom: DesignSystem.spacing.lg,
  },
  // Priority Styles
  priorityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: DesignSystem.spacing.md,
  },
  priorityButton: {
    width: '47%',
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    padding: DesignSystem.spacing.md,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  priorityButtonActive: {
    borderWidth: 2,
  },
  priorityCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: DesignSystem.spacing.sm,
  },
  priorityNumber: {
    ...DesignSystem.typography.h4,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  priorityInfo: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    textAlign: 'center',
  },
  priorityInfoActive: {
    color: theme.colors.text,
    fontWeight: '600',
  },
  // Helper Text
  helperText: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    marginBottom: DesignSystem.spacing.md,
  },
  // DateTimePicker Button Styles
  datePickerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.md,
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    paddingVertical: DesignSystem.spacing.md,
    paddingHorizontal: DesignSystem.spacing.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  datePickerInfo: {
    flex: 1,
  },
  datePickerLabel: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    marginBottom: 2,
  },
  datePickerValue: {
    ...DesignSystem.typography.body,
    fontWeight: '600',
    color: theme.colors.text,
  },
  datePickerPlaceholder: {
    color: theme.colors.textTertiary,
    fontWeight: '400',
  },
  // Critical Timer Styles
  timerDisplay: {
    alignItems: 'center',
    marginVertical: DesignSystem.spacing.md,
  },
  timerValueContainer: {
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.lg,
    paddingHorizontal: DesignSystem.spacing.xxxl,
    paddingVertical: DesignSystem.spacing.lg,
    borderWidth: 2,
    borderColor: theme.colors.border,
  },
  timerValue: {
    fontSize: 48,
    fontWeight: '700',
    color: theme.colors.text,
    textAlign: 'center',
  },
  timerUnit: {
    ...DesignSystem.typography.body,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginTop: DesignSystem.spacing.xs,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  sliderLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: DesignSystem.spacing.sm,
  },
  sliderLabel: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
  },
  // Assignment Styles
  assignmentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: DesignSystem.spacing.md,
  },
  assignmentLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.md,
  },
  assignmentText: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
  },
  employeeSelectionContainer: {
    marginTop: DesignSystem.spacing.sm,
    marginBottom: DesignSystem.spacing.md,
  },
  employeeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: DesignSystem.spacing.sm,
    paddingHorizontal: DesignSystem.spacing.sm,
  },
  employeeHeaderText: {
    ...DesignSystem.typography.bodySmall,
    color: theme.colors.textSecondary,
  },
  selectAllButton: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '600',
  },
  employeeList: {
    backgroundColor: theme.colors.background,
    borderRadius: DesignSystem.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    overflow: 'hidden',
  },
  employeeItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: DesignSystem.spacing.md,
    paddingHorizontal: DesignSystem.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  employeeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.md,
  },
  employeeAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  employeeInitials: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '700',
  },
  employeeName: {
    ...DesignSystem.typography.body,
    color: theme.colors.text,
  },
});
