// ============================================================================
// RECIPENDENT APP - UNIFIED DASHBOARD SCREEN (GLASSMORPHISM HEADER)
// ============================================================================
// ✅ Modern glassmorphism header mit Logo + Company Name
// ✅ Role-spezifische Inhalte (Admin vs Employee)
// ============================================================================

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  Platform,
  Image,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import AnimatedReanimated, {
  FadeInDown,
  FadeOutUp,
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing
} from 'react-native-reanimated';

import { useBranding } from "../../../shared/brandingContext";
import { useOrders } from '../../../shared/contexts/OrdersContext';
import { useTeam } from '../../../shared/contexts/TeamContext';
import { useAuth } from '../../auth/authContext';
import { useNotifications } from '../../../shared/notificationContext';
import RecipeCard from '../components/recipeCard';
import EmptyState from '../components/emptyState';
import DesignSystem from '../../../config/designSystem';
import BrandConfig from '../../../config/brandConfig';
import { useTheme } from '../../../shared/themeContext';
import GradientBackground from '../../../shared/components/GradientBackground';
import { TimeUtils } from '../../../shared/utils/timeUtils';

const UnifiedDashboardScreen = ({ navigation }) => {
  const { company, primaryColor } = useBranding();
  const { user } = useAuth();
  const { orders, refreshOrders } = useOrders();
  const { teamMembers } = useTeam();
  const { unreadCount } = useNotifications();
  const { currentTheme } = useTheme();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);
  const buttonTextColor = BrandConfig.getButtonTextColor(primaryColor, currentTheme.dark);

  const [filter, setFilter] = useState('open'); // 'open', 'critical', 'all', 'done'
  const [searchQuery, setSearchQuery] = useState('');
  const [searchExpanded, setSearchExpanded] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // ============================================================================
  // USER GREETING
  // ============================================================================
  const fullName = user?.first_name && user?.last_name
    ? `${user.first_name} ${user.last_name}`
    : user?.first_name || 'User';
  const greetingText = `Willkommen ${fullName}`;

  // ============================================================================
  // ROLE PERMISSIONS
  // ============================================================================
  const canCreateOrders = user?.role === 'admin' || user?.role === 'co-admin';

  // ============================================================================
  // PULL TO REFRESH
  // ============================================================================
  const onRefresh = async () => {
    setRefreshing(true);
    await refreshOrders();
    setRefreshing(false);
  };

  // ============================================================================
  // HELPER FUNCTIONS
  // ============================================================================
  const isCritical = (order) => {
    if (!order.due_date || order.status !== 'open') return false;
    return TimeUtils.isCritical(order.due_date, order.critical_timer || 4);
  };

  // Enrich orders with assigned user details
  const enrichedOrders = useMemo(() => {
    if (!orders || !Array.isArray(orders) || !teamMembers || !Array.isArray(teamMembers)) {
      return orders || [];
    }

    return orders.map(order => {
      if (!order.assigned_to || order.assigned_to.length === 0) {
        return order;
      }

      // Match assigned_to IDs with teamMembers
      const assignedUsers = order.assigned_to
        .map(userId => teamMembers.find(member => member.id === userId))
        .filter(Boolean); // Remove undefined matches

      return {
        ...order,
        assignedUsers
      };
    });
  }, [orders, teamMembers]);

  // Memoize filtered orders to prevent unnecessary re-renders
  const filteredOrders = useMemo(() => {
    if (!enrichedOrders || !Array.isArray(enrichedOrders)) return [];

    // Schritt 1: Filter nach Status
    let filtered = [];
    switch (filter) {
      case 'open':
        filtered = enrichedOrders.filter((o) => o.status === 'open' && !isCritical(o));
        break;
      case 'done':
        filtered = enrichedOrders.filter((o) => o.status === 'done');
        break;
      case 'critical':
        filtered = enrichedOrders.filter((o) => isCritical(o));
        break;
      default:
        filtered = enrichedOrders;
    }

    // Schritt 2: Filter nach Suchbegriff
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter((order) => {
        // Suche in: title, description, customer_name, category, location
        return (
          order.title?.toLowerCase().includes(query) ||
          order.description?.toLowerCase().includes(query) ||
          order.customer_name?.toLowerCase().includes(query) ||
          order.category?.toLowerCase().includes(query) ||
          order.location?.toLowerCase().includes(query) ||
          order.additional_text?.toLowerCase().includes(query)
        );
      });
    }

    return filtered;
  }, [enrichedOrders, filter, searchQuery]);

  const getFilterLabel = (filter) => {
    const labels = {
      all: 'Alle',
      open: 'Aktiv',
      done: 'Erledigt',
      critical: 'Kritisch',
    };
    return labels[filter];
  };

  const getFilterCount = (filterType) => {
    if (!orders || !Array.isArray(orders)) return 0;
    switch (filterType) {
      case 'open':
        return orders.filter((o) => o.status === 'open' && !isCritical(o)).length;
      case 'done':
        return orders.filter((o) => o.status === 'done').length;
      case 'critical':
        return orders.filter((o) => isCritical(o)).length;
      default:
        return orders.length;
    }
  };

  // ============================================================================
  // ✅ ROLE-AWARE EMPTY STATE CONTENT (Memoized)
  // ============================================================================
  const emptyStateContent = useMemo(() => {
    const isAdmin = canCreateOrders;

    // Wenn Suche aktiv ist, zeige spezifische Suche-Empty-State
    if (searchQuery.trim()) {
      return {
        icon: 'magnify',
        title: 'Keine Ergebnisse',
        subtitle: `Keine Aufträge gefunden für "${searchQuery}"`,
      };
    }

    const content = {
      all: {
        icon: 'clipboard-text-outline',
        title: 'Keine Aufträge',
        subtitle: isAdmin
          ? 'Erstelle deinen ersten Auftrag'
          : 'Es wurden noch keine Aufträge erstellt',
      },
      open: {
        icon: 'clipboard-check-outline',
        title: 'Keine aktiven Aufträge',
        subtitle: isAdmin
          ? 'Alle Aufträge sind erledigt oder kritisch'
          : 'Aktuell gibt es keine offenen Aufträge',
      },
      done: {
        icon: 'clipboard-check',
        title: 'Keine erledigten Aufträge',
        subtitle: 'Noch keine Aufträge abgeschlossen',
      },
      critical: {
        icon: 'alert-circle-outline',
        title: 'Keine kritischen Aufträge',
        subtitle: 'Sehr gut! Keine dringenden Aufträge',
      },
    };

    return content[filter] || content.all;
  }, [filter, searchQuery, canCreateOrders]);

  // ============================================================================
  // CRITICAL ORDERS STATUS
  // ============================================================================
  const criticalCount = useMemo(() => {
    return orders.filter((o) => isCritical(o)).length;
  }, [orders]);

  const hasCriticalOrders = criticalCount > 0;

  // ============================================================================
  // RENDER
  // ============================================================================
  return (
    <GradientBackground primaryColor={primaryColor} variant="default">
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        {/* HOME HEADER - Größer & prominenter für "Home"-Gefühl */}
        <View style={styles.headerContainer}>
          <BlurView
            intensity={currentTheme.isDark ? 100 : 90}
            tint={currentTheme.isDark ? 'prominent' : 'light'}
            style={styles.headerBlur}
          >
            <View style={styles.headerContent}>
              {/* Logo + Company Name + Ticker */}
              <View style={styles.headerMain}>
                <Image
                  source={
                    company?.show_logo_in_dashboard && company?.logo
                      ? { uri: company.logo }
                      : require('../../../assets/app/logo_appstore.png')
                  }
                  style={styles.headerLogo}
                  resizeMode="contain"
                />
                <View style={styles.headerTextContainer}>
                  {/* Einfacher Gruß-Text */}
                  <Text style={styles.headerGreeting} numberOfLines={1}>
                    {greetingText}
                  </Text>

                  <Text style={styles.headerTitle}>{company?.name || 'Dashboard'}</Text>

                  {/* Kritische Aufträge Status Badge */}
                  <View
                    style={[
                      styles.subtitleBadge,
                      {
                        borderColor: hasCriticalOrders
                          ? currentTheme.colors.critical
                          : currentTheme.colors.success,
                      },
                    ]}
                  >
                    <Text style={styles.headerSubtitle}>
                      {hasCriticalOrders
                        ? `${criticalCount} Kritische ${criticalCount === 1 ? 'Auftrag' : 'Aufträge'}`
                        : 'Keine kritischen Aufträge'}
                    </Text>
                  </View>
                </View>
              </View>

              {/* Notifications Icon with Badge */}
              <TouchableOpacity
                onPress={() => navigation.navigate('Notifications')}
                style={styles.headerIconButton}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <View>
                  <MaterialCommunityIcons
                    name="bell-outline"
                    size={40}
                    color={currentTheme.colors.text}
                  />
                  {unreadCount > 0 && (
                    <View style={[styles.notificationBadge, { backgroundColor: primaryColor }]}>
                      <Text style={styles.notificationBadgeText}>
                        {unreadCount > 99 ? '99+' : unreadCount}
                      </Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            </View>
          </BlurView>
        </View>

          {/* HORIZONTAL SEARCH + FILTER LAYOUT */}
          <View style={styles.horizontalFilterContainer}>
            <SearchBar
              value={searchQuery}
              onChangeText={setSearchQuery}
              expanded={searchExpanded}
              onExpand={() => setSearchExpanded(true)}
              onCollapse={() => {
                setSearchQuery('');
                setSearchExpanded(false);
              }}
              theme={currentTheme}
            />

            <FilterPills
              filters={['open', 'critical', 'all', 'done']}
              activeFilter={filter}
              onFilterChange={setFilter}
              getFilterLabel={getFilterLabel}
              getFilterCount={getFilterCount}
              primaryColor={primaryColor}
              theme={currentTheme}
              searchExpanded={searchExpanded}
            />
          </View>

          {/* CONTENT */}
          <ScrollView
            style={styles.scrollView}
            contentContainerStyle={styles.scrollContent}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
            }
            showsVerticalScrollIndicator={false}
          >
            {filteredOrders.length === 0 ? (
              <EmptyState
                icon={emptyStateContent.icon}
                title={emptyStateContent.title}
                subtitle={emptyStateContent.subtitle}
              />
            ) : (
              filteredOrders.map((order, index) => (
                <AnimatedReanimated.View
                  key={order.id}
                  entering={FadeInDown.delay(index * 50)}
                  exiting={FadeOutUp}
                >
                  <RecipeCard
                    order={order}
                    onPress={() => navigation.navigate('OrderDetail', { orderId: order.id })}
                    isCritical={isCritical(order)}
                    allTeamMembers={teamMembers}
                  />
                </AnimatedReanimated.View>
              ))
            )}
          </ScrollView>

        {/* FLOATING ACTION BUTTON - ✅ Nur für Admin & Co-Admin */}
        {canCreateOrders && (
          <TouchableOpacity
            style={[styles.fab, { backgroundColor: primaryColor }]}
            onPress={() => navigation.navigate('CreateOrder')}
            activeOpacity={0.8}
          >
            <MaterialCommunityIcons name="plus" size={28} color={buttonTextColor} />
          </TouchableOpacity>
        )}
      </SafeAreaView>
    </GradientBackground>
  );
};

// ============================================================================
// SEARCH BAR COMPONENT (Animated Expand/Collapse)
// ============================================================================
const SearchBar = React.memo(({ value, onChangeText, expanded, onExpand, onCollapse, theme }) => {
  const styles = React.useMemo(() => createStyles(theme), [theme]);
  const inputRef = React.useRef(null);

  // Animated values for smooth circle → pill transformation
  const searchWidth = useSharedValue(48);
  const searchPaddingLeft = useSharedValue(0); // No padding when collapsed
  const searchPaddingRight = useSharedValue(0);
  const iconSize = useSharedValue(24); // Icon size: 24px (collapsed) → 18px (expanded)
  const inputOpacity = useSharedValue(0); // Input field fade in/out
  const closeOpacity = useSharedValue(0); // Close button fade in/out

  React.useEffect(() => {
    const duration = 250;
    const config = {
      duration,
      easing: Easing.inOut(Easing.ease),
    };

    searchWidth.value = withTiming(expanded ? 200 : 48, config);
    searchPaddingLeft.value = withTiming(expanded ? 12 : 0, config);
    searchPaddingRight.value = withTiming(expanded ? 12 : 0, config);
    iconSize.value = withTiming(expanded ? 18 : 24, config);
    inputOpacity.value = withTiming(expanded ? 1 : 0, config);
    closeOpacity.value = withTiming(expanded ? 1 : 0, config);

    // Auto-focus input when expanded
    if (expanded) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [expanded]);

  const animatedContainerStyle = useAnimatedStyle(() => ({
    width: searchWidth.value,
    paddingLeft: searchPaddingLeft.value,
    paddingRight: searchPaddingRight.value,
  }));

  const animatedIconStyle = useAnimatedStyle(() => ({
    transform: [{ scale: iconSize.value / 24 }], // Scale: 1 (24px) → 0.75 (18px)
  }));

  const animatedInputStyle = useAnimatedStyle(() => ({
    opacity: inputOpacity.value,
  }));

  const animatedCloseStyle = useAnimatedStyle(() => ({
    opacity: closeOpacity.value,
  }));

  return (
    <AnimatedReanimated.View style={[styles.searchContainer, animatedContainerStyle]}>
      <TouchableOpacity
        onPress={expanded ? undefined : onExpand}
        style={styles.searchContentWrapper}
        activeOpacity={expanded ? 1 : 0.7}
        disabled={expanded}
      >
        {/* Search Icon - Always visible, animates size */}
        <AnimatedReanimated.View style={animatedIconStyle}>
          <MaterialCommunityIcons
            name="magnify"
            size={24}
            color={expanded ? theme.colors.textTertiary : theme.colors.text}
          />
        </AnimatedReanimated.View>

        {/* Input Field - Only rendered when expanded */}
        {expanded && (
          <AnimatedReanimated.View style={[styles.searchInputContainer, animatedInputStyle]}>
            <TextInput
              ref={inputRef}
              style={styles.searchInput}
              placeholder="Suchen..."
              placeholderTextColor={theme.colors.textTertiary}
              selectionColor={primaryColor}
              cursorColor={primaryColor}
              underlineColorAndroid="transparent"
              value={value}
              onChangeText={onChangeText}
              returnKeyType="search"
              autoCapitalize="none"
              autoCorrect={false}
            />
          </AnimatedReanimated.View>
        )}

        {/* Close Button - Only rendered when expanded */}
        {expanded && (
          <AnimatedReanimated.View style={animatedCloseStyle}>
            <TouchableOpacity
              onPress={onCollapse}
              style={styles.searchCloseButton}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <MaterialCommunityIcons
                name="close"
                size={18}
                color={theme.colors.textSecondary}
              />
            </TouchableOpacity>
          </AnimatedReanimated.View>
        )}
      </TouchableOpacity>
    </AnimatedReanimated.View>
  );
});

// ============================================================================
// FILTER PILLS CONTAINER (Animated horizontal shift)
// ============================================================================
const FilterPills = React.memo(({
  filters,
  activeFilter,
  onFilterChange,
  getFilterLabel,
  getFilterCount,
  primaryColor,
  theme,
  searchExpanded,
}) => {
  const styles = React.useMemo(() => createStyles(theme), [theme]);

  // Animated marginLeft: pills shift when search expands
  const pillsMargin = useSharedValue(0);

  React.useEffect(() => {
    pillsMargin.value = withTiming(searchExpanded ? 8 : 0, {
      duration: 250,
      easing: Easing.inOut(Easing.ease),
    });
  }, [searchExpanded]);

  const animatedStyle = useAnimatedStyle(() => ({
    marginLeft: pillsMargin.value,
  }));

  return (
    <AnimatedReanimated.View style={[styles.filterPillsContainer, animatedStyle]}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterScrollContent}
      >
        {filters.map((f) => (
          <FilterPill
            key={f}
            label={getFilterLabel(f)}
            count={getFilterCount(f)}
            active={activeFilter === f}
            onPress={() => onFilterChange(f)}
            color={primaryColor}
            theme={theme}
            isDark={theme.isDark}
          />
        ))}
      </ScrollView>
    </AnimatedReanimated.View>
  );
});

// ============================================================================
// FILTER PILL COMPONENT (Single Pill)
// ============================================================================
const FilterPill = ({ label, count, active, onPress, color, theme, isDark }) => {
  const pillStyles = React.useMemo(() => createStyles(theme), [theme]);
  const textColor = BrandConfig.getButtonTextColor(color, isDark);

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        pillStyles.pill,
        active && { backgroundColor: color },
      ]}
      activeOpacity={0.7}
    >
      <Text style={[
        pillStyles.pillText,
        active && { color: textColor }
      ]}>
        {label}
      </Text>
      {count > 0 && (
        <View style={[pillStyles.pillBadge, active && pillStyles.pillBadgeActive]}>
          <Text style={[
            pillStyles.pillBadgeText,
            active && { color: textColor }
          ]}>
            {count}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

// ============================================================================
// STYLES
// ============================================================================
const createStyles = (theme) => StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  // Home Header - Größer & prominenter
  headerContainer: {
    marginHorizontal: DesignSystem.spacing.lg,
    marginTop: DesignSystem.spacing.md,
    marginBottom: DesignSystem.spacing.lg,
    borderRadius: DesignSystem.borderRadius.xxl,
    overflow: 'hidden',
    ...DesignSystem.shadows.lg,
  },
  headerBlur: {
    borderWidth: 1,
    borderColor: theme.isDark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.08)',
    borderRadius: DesignSystem.borderRadius.xxl,
    overflow: 'hidden',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center', // Mittig für Settings Icon
    justifyContent: 'space-between',
    paddingHorizontal: DesignSystem.spacing.xl,
    paddingTop: DesignSystem.spacing.xl,
    paddingBottom: DesignSystem.spacing.xl,
  },
  headerMain: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: DesignSystem.spacing.lg,
  },
  headerLogo: {
    width: 80,
    height: 80,
    borderRadius: DesignSystem.borderRadius.lg,
  },
  headerTextContainer: {
    flex: 1,
  },
  headerGreeting: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    fontSize: 13,
    fontWeight: '450',
    textTransform: 'camelcase',
    letterSpacing: 1,
    marginBottom: 4,
  },
  headerTitle: {
    ...DesignSystem.typography.h2,
    color: theme.colors.text,
    fontWeight: '800',
    marginBottom: 6,
  },
  // Umrahmte Auftrags-Badge
  subtitleBadge: {
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: DesignSystem.borderRadius.lg,
    paddingHorizontal: DesignSystem.spacing.sm,
    paddingVertical: 4,
  },
  headerSubtitle: {
    ...DesignSystem.typography.caption,
    color: theme.colors.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },
  headerIconButton: {
    padding: DesignSystem.spacing.sm,
  },
  notificationBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: theme.colors.background,
  },
  notificationBadgeText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '700',
  },
  // Horizontal Search + Filter Container
  horizontalFilterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: DesignSystem.spacing.lg,
    paddingVertical: DesignSystem.spacing.sm, // 8px (vorher md=12px)
    gap: DesignSystem.spacing.sm,
  },
  // Search Container (Animated: Circle → Pill, constant borderRadius)
  searchContainer: {
    height: 36,
    borderRadius: 24, // Constant: Perfect semicircles on left/right (50% of height)
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
    justifyContent: 'center',
    overflow: 'hidden',
    ...DesignSystem.shadows.sm,
  },
  // Content wrapper (always rendered)
  searchContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center', // Center icon when collapsed
    height: '100%',
    width: '100%',
  },
  // Input container (fades in/out)
  searchInputContainer: {
    flex: 1,
    marginLeft: DesignSystem.spacing.xs,
  },
  searchInput: {
    ...DesignSystem.typography.input,
    color: theme.colors.text,
    fontSize: 14,
    lineHeight: 22, // Erhöht für vollständige Descender-Darstellung
    paddingVertical: 6, // Erhöhtes Padding für sichere Descender-Darstellung (g, p, q, y, j)
    includeFontPadding: true, // Android: Font-Padding einschließen
  },
  searchCloseButton: {
    padding: DesignSystem.spacing.xs,
    marginLeft: DesignSystem.spacing.xs,
  },
  // Filter Pills Container
  filterPillsContainer: {
    flex: 1,
  },
  filterScrollContent: {
    paddingHorizontal: DesignSystem.spacing.xs,
    gap: DesignSystem.spacing.sm,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: DesignSystem.spacing.md, // 12px (vorher lg=16px)
    paddingVertical: DesignSystem.spacing.sm,
    borderRadius: DesignSystem.borderRadius.xl,
    backgroundColor: theme.colors.surface,
    borderWidth: 1,
    borderColor: theme.colors.border,
    gap: DesignSystem.spacing.sm,
    height: 36
  },
  pillText: {
    ...DesignSystem.typography.bodySmall,
    fontWeight: '600',
    color: theme.colors.textSecondary,
  },
  pillTextActive: {
    color: theme.colors.textOnPrimary,
  },
  pillBadge: {
    backgroundColor: theme.colors.border,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: DesignSystem.borderRadius.round,
    minWidth: 24,
    alignItems: 'center',
  },
  pillBadgeActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  pillBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.textSecondary,
  },
  pillBadgeTextActive: {
    color: theme.colors.textOnPrimary,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: DesignSystem.spacing.xl,
    paddingTop: DesignSystem.spacing.md, // 12px (vorher xl=20px)
    paddingBottom: Platform.OS === 'ios' ? 120 : 100,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
    backgroundColor: theme.colors.background,
  },
  loadingText: {
    ...DesignSystem.typography.body,
    color: theme.colors.textTertiary,
  },
  fab: {
    position: 'absolute',
    right: DesignSystem.spacing.xl,
    bottom: Platform.OS === 'ios' ? 110 : 90,
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    ...DesignSystem.shadows.lg,
  },
});

// Enable Why Did You Render tracking
if (__DEV__) {
  UnifiedDashboardScreen.whyDidYouRender = true;
}

export default UnifiedDashboardScreen;