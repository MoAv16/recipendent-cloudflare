import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useAuth } from '../../auth/authContext';
import { getOrders } from '../services/crudOperations';
import { subscribeToOrders } from '../services/realtimeService';
import { useTheme } from '../../../shared/themeContext';
import { useBranding } from '../../../shared/brandingContext';
import GlassCard from '../../../shared/components/GlassCard';
import GlassButton from '../../../shared/components/GlassButton';

export default function CompletedOrdersScreen({ navigation }) {
  const { company } = useAuth();
  const { currentTheme } = useTheme();
  const { primaryColor } = useBranding();
  const styles = React.useMemo(() => createStyles(currentTheme), [currentTheme]);

  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState('completed');

  // Nur beim ersten Mount laden - Realtime übernimmt danach alle Updates
  useEffect(() => {
    if (company?.id) {
      loadOrders();
    }
  }, []); // Keine Dependencies - nur einmalig laden!

  // Realtime Subscription - Live Updates ohne Reload
  useEffect(() => {
    const unsubscribe = subscribeToOrders(
      (newOrder) => {
        // Neue Orders sind nie completed - ignorieren
      },
      (updatedOrder) => {
        console.log('🔴 [Realtime] Auftrag aktualisiert:', updatedOrder.title);
        if (updatedOrder.status === 'done') {
          // Order auf done gesetzt - zur Liste hinzufügen
          setOrders(prev => {
            const exists = prev.find(o => o.id === updatedOrder.id);
            if (exists) {
              return prev.map(o => o.id === updatedOrder.id ? updatedOrder : o);
            } else {
              return [updatedOrder, ...prev];
            }
          });
        } else {
          // Order auf open gesetzt - aus Liste entfernen
          setOrders(prev => prev.filter(o => o.id !== updatedOrder.id));
        }
      },
      (deletedOrder) => {
        console.log('🔴 [Realtime] Auftrag gelöscht:', deletedOrder.id);
        setOrders(prev => prev.filter(o => o.id !== deletedOrder.id));
      }
    );

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []); // Keine Dependencies - Subscription bleibt aktiv

  const loadOrders = async () => {
    try {
      setLoading(true);

      const data = await getOrders('done'); // Nur erledigte Orders
      setOrders(data || []);
    } catch (error) {
      console.error('Fehler beim Laden der Aufträge:', error);
      Alert.alert('Fehler', 'Aufträge konnten nicht geladen werden');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const filteredOrders = orders.filter(o =>
    filter === 'completed' ? o.status === 'completed' : o.status === 'critical'
  );

  const renderOrderItem = ({ item }) => (
    <GlassCard
      intensity={40}
      style={styles.orderCard}
      onPress={() => navigation.navigate('OrderDetail', { orderId: item.id })}
    >
      <View style={styles.orderHeader}>
        <Text style={styles.orderTitle} numberOfLines={1}>
          {item.title}
        </Text>
        <View
          style={[
            styles.statusBadge,
            { backgroundColor: item.status === 'critical' ? '#FF4444' : '#4CAF50' },
          ]}
        >
          <Text style={styles.statusText}>
            {item.status === 'critical' ? 'Kritisch' : 'Erledigt'}
          </Text>
        </View>
      </View>

      <Text style={styles.orderDescription} numberOfLines={2}>
        {item.description}
      </Text>
    </GlassCard>
  );

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, styles.centerContent]} edges={['top', 'left', 'right']}>
        <ActivityIndicator size="large" color={primaryColor} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <StatusBar style="auto" />

      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          Aufträge
        </Text>
      </View>

      <View style={styles.filterContainer}>
        <GlassButton
          title="Erledigt"
          variant={filter === 'completed' ? 'primary' : 'secondary'}
          onPress={() => setFilter('completed')}
          style={styles.filterButton}
        />
        <GlassButton
          title="Kritisch"
          variant={filter === 'critical' ? 'primary' : 'secondary'}
          onPress={() => setFilter('critical')}
          style={styles.filterButton}
        />
      </View>

      <FlatList
        data={filteredOrders}
        renderItem={renderOrderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={filteredOrders.length === 0 ? styles.emptyListContainer : styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[primaryColor]} tintColor={primaryColor} />
        }
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              Keine {filter === 'completed' ? 'erledigten' : 'kritischen'} Aufträge
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const createStyles = (theme) => StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.surface },
  header: { paddingHorizontal: 20, paddingBottom: 20, borderBottomWidth: 1, borderBottomColor: '#e0e0e0' },
  headerTitle: { fontSize: 28, fontWeight: 'bold', color: theme.colors.text },
  headerTitleDark: { color: theme.colors.text },
  filterContainer: { flexDirection: 'row', padding: 16, gap: 8 },
  filterContainerDark: { backgroundColor: theme.colors.surface },
  filterButton: { flex: 1, paddingVertical: 12, borderRadius: 8, backgroundColor: '#e0e0e0', alignItems: 'center' },
  filterButtonActive: { backgroundColor: '#bc79e0' },
  filterButtonText: { fontSize: 14, color: theme.colors.textSecondary },
  filterButtonTextActive: { color: theme.colors.text, fontWeight: '600' },
  listContent: { padding: 16, paddingBottom: 100 },
  emptyListContainer: { flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 16, paddingBottom: 100 },
  orderCard: { backgroundColor: theme.colors.surfaceVariant, borderRadius: 12, padding: 16, marginBottom: 12 },
  orderCardDark: { backgroundColor: theme.colors.surface },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  orderTitle: { fontSize: 16, fontWeight: '600', color: theme.colors.text, flex: 1 },
  orderTitleDark: { color: theme.colors.text },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12, marginLeft: 8 },
  statusText: { fontSize: 12, color: theme.colors.text, fontWeight: '600' },
  orderDescription: { fontSize: 14, color: theme.colors.textSecondary },
  orderDescriptionDark: { color: theme.colors.textSecondary },
  emptyState: { justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 16, color: theme.colors.textSecondary, textAlign: 'center' },
