// ============================================================================
// REALTIME SUBSCRIPTIONS - RECIPENDENT APP
// ============================================================================
// Datei: utils/realtimeService.js
// Beschreibung: Realtime-Subscriptions für Live-Updates zwischen Geräten
// ============================================================================

import { supabase, getCurrentCompanyId } from '../../../config/supabaseClient';
import logger from '../../../shared/utils/logger';

// ============================================================================
// ORDERS REALTIME SUBSCRIPTION
// ============================================================================

/**
 * Abonniere Änderungen an Aufträgen in Echtzeit
 * Automatisch gefiltert nach company_id durch RLS
 * 
 * @param {Function} onInsert - Callback wenn neuer Auftrag erstellt
 * @param {Function} onUpdate - Callback wenn Auftrag geändert
 * @param {Function} onDelete - Callback wenn Auftrag gelöscht
 * @returns {Function} - Unsubscribe-Funktion
 * 
 * @example
 * const unsubscribe = subscribeToOrders(
 *   (newOrder) => logger.realtime('Neuer Auftrag:', newOrder),
 *   (updatedOrder) => logger.realtime('Auftrag geändert:', updatedOrder),
 *   (deletedOrder) => logger.realtime('Auftrag gelöscht:', deletedOrder)
 * );
 * 
 * // Später: unsubscribe();
 */
export const subscribeToOrders = (onInsert, onUpdate, onDelete) => {
  const subscription = supabase
    .channel('orders_channel')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'orders',
      },
      (payload) => {
        logger.realtime('Realtime INSERT:', payload.new);
        if (onInsert) onInsert(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'orders',
      },
      (payload) => {
        logger.realtime('Realtime UPDATE:', payload.new);
        if (onUpdate) onUpdate(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'DELETE',
        schema: 'public',
        table: 'orders',
      },
      (payload) => {
        logger.realtime('Realtime DELETE:', payload.old);
        if (onDelete) onDelete(payload.old);
      }
    )
    .subscribe((status) => {
      logger.realtime('Orders subscription status:', status);
    });
  
  // Return unsubscribe function
  return () => {
    logger.realtime('Unsubscribing from orders channel');
    supabase.removeChannel(subscription);
  };
};

// ============================================================================
// USERS REALTIME SUBSCRIPTION
// ============================================================================

/**
 * Abonniere Änderungen an Mitarbeitern in Echtzeit
 * 
 * @param {Function} onInsert - Callback wenn neuer Mitarbeiter
 * @param {Function} onUpdate - Callback wenn Mitarbeiter geändert
 * @param {Function} onDelete - Callback wenn Mitarbeiter gelöscht
 * @returns {Function} - Unsubscribe-Funktion
 */
export const subscribeToUsers = (onInsert, onUpdate, onDelete) => {
  const subscription = supabase
    .channel('users_channel')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'users',
      },
      (payload) => {
        logger.realtime('Realtime USER INSERT:', payload.new);
        if (onInsert) onInsert(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'users',
      },
      (payload) => {
        logger.realtime('Realtime USER UPDATE:', payload.new);
        if (onUpdate) onUpdate(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'DELETE',
        schema: 'public',
        table: 'users',
      },
      (payload) => {
        logger.realtime('Realtime USER DELETE:', payload.old);
        if (onDelete) onDelete(payload.old);
      }
    )
    .subscribe((status) => {
      logger.realtime('Users subscription status:', status);
    });
  
  return () => {
    logger.realtime('Unsubscribing from users channel');
    supabase.removeChannel(subscription);
  };
};

// ============================================================================
// FOLDERS REALTIME SUBSCRIPTION
// ============================================================================

/**
 * Abonniere Änderungen an Folders in Echtzeit
 *
 * @param {Function} onInsert - Callback wenn neuer Folder
 * @param {Function} onUpdate - Callback wenn Folder geändert
 * @param {Function} onDelete - Callback wenn Folder gelöscht
 * @returns {Function} - Unsubscribe-Funktion
 */
export const subscribeToFolders = (onInsert, onUpdate, onDelete) => {
  const subscription = supabase
    .channel('folders_channel')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'folders',
      },
      (payload) => {
        logger.realtime('Realtime FOLDER INSERT:', payload.new);
        if (onInsert) onInsert(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'folders',
      },
      (payload) => {
        logger.realtime('Realtime FOLDER UPDATE:', payload.new);
        if (onUpdate) onUpdate(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'DELETE',
        schema: 'public',
        table: 'folders',
      },
      (payload) => {
        logger.realtime('Realtime FOLDER DELETE:', payload.old);
        if (onDelete) onDelete(payload.old);
      }
    )
    .subscribe((status) => {
      logger.realtime('Folders subscription status:', status);
    });

  return () => {
    logger.realtime('Unsubscribing from folders channel');
    supabase.removeChannel(subscription);
  };
};

// ============================================================================
// RECIPE TEMPLATES REALTIME SUBSCRIPTION
// ============================================================================

/**
 * Abonniere Änderungen an Recipe Templates in Echtzeit
 * 
 * @param {Function} onInsert - Callback wenn neues Template
 * @param {Function} onUpdate - Callback wenn Template geändert
 * @param {Function} onDelete - Callback wenn Template gelöscht
 * @returns {Function} - Unsubscribe-Funktion
 */
export const subscribeToRecipeTemplates = (onInsert, onUpdate, onDelete) => {
  const subscription = supabase
    .channel('templates_channel')
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'recipe_templates',
      },
      (payload) => {
        logger.realtime('Realtime TEMPLATE INSERT:', payload.new);
        if (onInsert) onInsert(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'recipe_templates',
      },
      (payload) => {
        logger.realtime('Realtime TEMPLATE UPDATE:', payload.new);
        if (onUpdate) onUpdate(payload.new);
      }
    )
    .on(
      'postgres_changes',
      {
        event: 'DELETE',
        schema: 'public',
        table: 'recipe_templates',
      },
      (payload) => {
        logger.realtime('Realtime TEMPLATE DELETE:', payload.old);
        if (onDelete) onDelete(payload.old);
      }
    )
    .subscribe((status) => {
      logger.realtime('Templates subscription status:', status);
    });
  
  return () => {
    logger.realtime('Unsubscribing from templates channel');
    supabase.removeChannel(subscription);
  };
};

// ============================================================================
// UNIFIED SUBSCRIPTION (alle Tabellen gleichzeitig)
// ============================================================================

/**
 * Abonniere ALLE relevanten Tabellen in einer Subscription
 * Nützlich für Dashboards, die alle Änderungen tracken müssen
 * 
 * @param {Object} callbacks
 * @param {Object} callbacks.orders - { onInsert, onUpdate, onDelete }
 * @param {Object} callbacks.users - { onInsert, onUpdate, onDelete }
 * @param {Object} callbacks.templates - { onInsert, onUpdate, onDelete }
 * @returns {Function} - Unsubscribe-Funktion für alle Subscriptions
 */
export const subscribeToAll = (callbacks) => {
  const unsubscribes = [];
  
  // Orders
  if (callbacks.orders) {
    const unsubOrders = subscribeToOrders(
      callbacks.orders.onInsert,
      callbacks.orders.onUpdate,
      callbacks.orders.onDelete
    );
    unsubscribes.push(unsubOrders);
  }
  
  // Users
  if (callbacks.users) {
    const unsubUsers = subscribeToUsers(
      callbacks.users.onInsert,
      callbacks.users.onUpdate,
      callbacks.users.onDelete
    );
    unsubscribes.push(unsubUsers);
  }
  
  // Templates
  if (callbacks.templates) {
    const unsubTemplates = subscribeToRecipeTemplates(
      callbacks.templates.onInsert,
      callbacks.templates.onUpdate,
      callbacks.templates.onDelete
    );
    unsubscribes.push(unsubTemplates);
  }
  
  // Return unified unsubscribe function
  return () => {
    unsubscribes.forEach(unsub => unsub());
  };
};

// ============================================================================
// USAGE BEISPIEL
// ============================================================================

/*
// In deinem Dashboard-Screen (z.B. AdminDashboardScreen.js):

import React, { useState, useEffect } from 'react';
import { subscribeToOrders } from './utils/realtimeService';
import { getOrders } from './utils/crudOperations';

const AdminDashboardScreen = () => {
  const [orders, setOrders] = useState([]);
  
  // Initial load
  useEffect(() => {
    loadOrders();
  }, []);
  
  const loadOrders = async () => {
    const data = await getOrders();
    setOrders(data);
  };
  
  // Realtime subscription
  useEffect(() => {
    const unsubscribe = subscribeToOrders(
      // INSERT: Neuer Auftrag erstellt
      (newOrder) => {
        logger.realtime('Neuer Auftrag empfangen:', newOrder.title);
        setOrders(prev => [newOrder, ...prev]);
        
        // Optional: Toast/Notification anzeigen
        Alert.alert('Neuer Auftrag', newOrder.title);
      },
      
      // UPDATE: Auftrag geändert
      (updatedOrder) => {
        logger.realtime('Auftrag aktualisiert:', updatedOrder.title);
        setOrders(prev => 
          prev.map(order => 
            order.id === updatedOrder.id ? updatedOrder : order
          )
        );
      },
      
      // DELETE: Auftrag gelöscht
      (deletedOrder) => {
        logger.realtime('Auftrag gelöscht:', deletedOrder.id);
        setOrders(prev => 
          prev.filter(order => order.id !== deletedOrder.id)
        );
      }
    );
    
    // Cleanup: Unsubscribe beim Unmount
    return () => {
      unsubscribe();
    };
  }, []);
  
  return (
    <View>
      <Text>Aufträge: {orders.length}</Text>
      <FlatList
        data={orders}
        renderItem={({ item }) => (
          <View>
            <Text>{item.title}</Text>
            <Text>Status: {item.status}</Text>
          </View>
        )}
        keyExtractor={item => item.id}
      />
    </View>
  );
};
*/

/*
// Beispiel: Unified Subscription (alle Tabellen)

useEffect(() => {
  const unsubscribe = subscribeToAll({
    orders: {
      onInsert: (newOrder) => {
        setOrders(prev => [newOrder, ...prev]);
      },
      onUpdate: (updatedOrder) => {
        setOrders(prev => prev.map(o => o.id === updatedOrder.id ? updatedOrder : o));
      },
      onDelete: (deletedOrder) => {
        setOrders(prev => prev.filter(o => o.id !== deletedOrder.id));
      },
    },
    users: {
      onInsert: (newUser) => {
        setUsers(prev => [newUser, ...prev]);
      },
      onDelete: (deletedUser) => {
        setUsers(prev => prev.filter(u => u.id !== deletedUser.id));
      },
    },
  });
  
  return () => unsubscribe();
}, []);
*/

// ============================================================================
// WICHTIGE HINWEISE
// ============================================================================

/*
1. RLS FILTERING:
   - Realtime-Events werden automatisch von RLS gefiltert
   - Du empfängst nur Änderungen von Aufträgen deiner eigenen Company
   - Keine manuelle Filterung nötig!

2. PERFORMANCE:
   - Subscriptions bleiben aktiv, auch wenn App im Hintergrund
   - Cleanup wichtig: useEffect return function
   - Bei vielen Subscriptions: Nutze subscribeToAll()

3. OFFLINE HANDLING:
   - Supabase Realtime funktioniert nicht offline
   - Events werden NICHT nachgeholt nach Reconnect
   - Lösung: Bei App-Start immer vollständiges Reload

4. DEBUGGING:
   - Console.logs zeigen alle Realtime-Events
   - Subscription status: "SUBSCRIBED" = aktiv
   - Bei Problemen: Check Supabase Dashboard → Database → Replication

5. TESTING:
   - Teste mit 2 Geräten/Tabs gleichzeitig
   - Erstelle Auftrag auf Gerät A → sollte sofort auf Gerät B erscheinen
   - Bei Verzögerung: Check Netzwerkverbindung
*/
