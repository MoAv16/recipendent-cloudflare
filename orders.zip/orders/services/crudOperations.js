// ============================================================================
// RECIPENDENT APP - EXTENDED CRUD OPERATIONS
// ============================================================================
// Erweiterte CRUD-Funktionen für Orders, Users, Folders
// ============================================================================

import { supabase } from '../../../config/supabaseClient';
import { getCurrentCompanyId, getCurrentUser } from '../../../config/supabaseClient';
import notificationService from '../../../shared/services/notificationService';
import logger from '../../../shared/utils/logger';

// ============================================================================
// ORDERS (Aufträge)
// ============================================================================

/**
 * Alle Aufträge der eigenen Company laden
 * @param {string} status - Optional: "open", "done" oder null (alle)
 * @param {string} folderId - Optional: Nur Aufträge aus diesem Ordner
 * @returns {Promise<Array>}
 */
export const getOrders = async (status = null, folderId = undefined) => {
  try {
    let query = supabase
      .from('orders')
      .select(`
        *,
        author:author_id (
          profile_picture,
          id,
          email
        )
      `)
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    // Filter nach Ordner: nur wenn folderId einen echten Wert hat
    // folderId === null bedeutet "Alle Rezepte" → kein Filter anwenden
    if (folderId !== undefined && folderId !== null) {
      query = query.eq('folder_id', folderId);
    }

    const { data, error } = await query;

    if (error) {
      logger.error('Error fetching orders:', error);
      return [];
    }

    // Load assigned users for each order
    const ordersWithUsers = await Promise.all(
      (data || []).map(async (order) => {
        if (order.assigned_to && order.assigned_to.length > 0) {
          const { data: assignedUsers, error: usersError } = await supabase
            .from('users')
            .select('id, first_name, last_name, profile_picture')
            .in('id', order.assigned_to);

          if (!usersError && assignedUsers) {
            return { ...order, assignedUsers };
          }
        }
        return { ...order, assignedUsers: [] };
      })
    );

    return ordersWithUsers;
  } catch (error) {
    logger.error('Get orders error:', error);
    return [];
  }
};

/**
 * Einzelnen Auftrag anhand ID laden
 */
export const getOrderById = async (orderId) => {
  try {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (error) {
      logger.error('Error fetching order:', error);
      return null;
    }

    // Load assigned users
    if (data && data.assigned_to && data.assigned_to.length > 0) {
      const { data: assignedUsers, error: usersError } = await supabase
        .from('users')
        .select('id, first_name, last_name, profile_picture')
        .in('id', data.assigned_to);

      if (!usersError && assignedUsers) {
        return { ...data, assignedUsers };
      }
    }

    return { ...data, assignedUsers: [] };
  } catch (error) {
    logger.error('Get order error:', error);
    return null;
  }
};

/**
 * Neuen Auftrag erstellen (ERWEITERT mit neuen Feldern)
 */
export const createOrder = async (orderData) => {
  try {
    const companyId = await getCurrentCompanyId();
    const currentUser = await getCurrentUser();

    if (!companyId || !currentUser) {
      return { success: false, error: 'Nicht eingeloggt.' };
    }

    // Hole User-Details für author_name
    const { data: userData } = await supabase
      .from('users')
      .select('first_name, last_name')
      .eq('id', currentUser.id)
      .single();

    const authorName = userData
      ? `${userData.first_name} ${userData.last_name}`
      : 'Unbekannt';

    const { data, error } = await supabase
      .from('orders')
      .insert({
        company_id: companyId,
        title: orderData.title,
        description: orderData.description || '',
        additional_text: orderData.additionalText || null,
        customer_name: orderData.customerName || null,
        category: orderData.category || null,
        location: orderData.location || null,
        image_url: orderData.imageUrl || null,
        folder_id: orderData.folderId || null,
        priority: orderData.priority || null,
        due_date: orderData.dueDate || null,
        critical_timer: orderData.criticalTimer || 2,
        status: 'open',
        author_id: currentUser.id,
        author_name: authorName,
        assigned_to: orderData.assignedTo || [],
        editable_by_assigned: orderData.editableByAssigned || false,
        notes: [],
      })
      .select()
      .single();

    if (error) {
      logger.error('Error creating order:', error);
      return { success: false, error: 'Fehler beim Erstellen: ' + error.message };
    }

    // ✅ Send notifications
    try {
      // 1. Send notification to assigned users
      if (data.assigned_to && data.assigned_to.length > 0) {
        await notificationService.sendOrderAssignedNotification({
          orderId: data.id,
          orderTitle: data.title,
          assignedUserIds: data.assigned_to,
          companyId,
          authorName,
        });
      }

      // 2. Send notification to users with "all_orders" enabled
      await notificationService.sendNewOrderNotification({
        orderId: data.id,
        orderTitle: data.title,
        companyId,
        authorName,
      });

      // 3. If critical order, send critical notification
      if (data.priority === 4) {
        await notificationService.sendCriticalOrderNotification({
          orderId: data.id,
          orderTitle: data.title,
          companyId,
          authorName,
        });
      }
    } catch (notifError) {
      logger.error('Error sending notifications:', notifError);
      // Don't fail order creation if notifications fail
    }

    return { success: true, data: data };
  } catch (error) {
    logger.error('Create order error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Auftrag aktualisieren (ERWEITERT)
 */
export const updateOrder = async (orderId, updates) => {
  try {
    // Füge updated_at hinzu
    const updatesWithTimestamp = {
      ...updates,
      updated_at: new Date().toISOString(),
    };
    
    // Auto-reset status from overdue to open wenn due_date in die Zukunft geändert wird
    if (updates.due_date) {
      const newDueDate = new Date(updates.due_date);
      const now = new Date();
      
      // Fetch current order status
      const { data: currentOrder } = await supabase
        .from('orders')
        .select('status')
        .eq('id', orderId)
        .single();
      
      // Wenn Status aktuell overdue ist UND neues Datum in Zukunft liegt
      if (currentOrder?.status === 'overdue' && newDueDate > now) {
        updatesWithTimestamp.status = 'open';
        updatesWithTimestamp.status_changed_at = new Date().toISOString();
        updatesWithTimestamp.status_changed_by = (await supabase.auth.getUser()).data.user?.id;
      }
    }

    const { data, error } = await supabase
      .from('orders')
      .update(updatesWithTimestamp)
      .eq('id', orderId)
      .select();

    if (error) {
      logger.error('Error updating order:', error);
      return { success: false, error: 'Fehler beim Aktualisieren: ' + error.message };
    }

    // Prüfe ob Update erfolgreich war (mindestens 1 Zeile betroffen)
    if (!data || data.length === 0) {
      logger.error('No rows updated - possible RLS policy issue or order not found');
      return { success: false, error: 'Auftrag konnte nicht aktualisiert werden. Möglicherweise fehlen Berechtigungen.' };
    }

    return { success: true, data: data[0] };
  } catch (error) {
    logger.error('Update order error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Status ändern mit Tracking
 */
const getStatusLabel = (status) => {
  const statusLabels = {
    open: 'Offen',
    done: 'Erledigt',
    archived: 'Archiviert',
  };
  return statusLabels[status] || status;
};

export const updateOrderStatus = async (orderId, newStatus) => {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return { success: false, error: 'Nicht eingeloggt.' };
    }

    // Lade aktuellen Auftrag
    const order = await getOrderById(orderId);
    if (!order) {
      return { success: false, error: 'Auftrag nicht gefunden.' };
    }

    // Hole User-Details
    const { data: userData } = await supabase
      .from('users')
      .select('first_name, last_name')
      .eq('id', currentUser.id)
      .single();

    const authorName = userData
      ? `${userData.first_name} ${userData.last_name}`
      : 'Unbekannt';

    // Erstelle Status-Change-Note mit deutschen Labels
    const statusChangeNote = {
      id: `note_${Date.now()}`,
      type: 'status_change',
      text: `Status geändert: ${getStatusLabel(order.status)} → ${getStatusLabel(newStatus)}`,
      author: authorName,
      author_id: currentUser.id,
      timestamp: new Date().toISOString(),
      old_status: order.status,
      new_status: newStatus,
    };

    // Füge Note zu notes hinzu
    const updatedNotes = [...(order.notes || []), statusChangeNote];

    // Update Order
    const result = await updateOrder(orderId, {
      status: newStatus,
      status_changed_by: currentUser.id,
      status_changed_at: new Date().toISOString(),
      notes: updatedNotes,
    });

    // ✅ Send notification to assigned users (except the status changer)
    if (result.success && order.assigned_to && order.assigned_to.length > 0) {
      try {
        const companyId = await getCurrentCompanyId();
        // Filter out the author - they shouldn't get notified about their own status change
        const recipientIds = order.assigned_to.filter(userId => userId !== currentUser.id);

        if (recipientIds.length > 0) {
          await notificationService.sendOrderStatusChangedNotification({
            orderId: order.id,
            orderTitle: order.title,
            assignedUserIds: recipientIds,
            companyId,
            authorName,
            newStatus,
          });
        }
      } catch (notifError) {
        logger.error('Error sending status change notification:', notifError);
      }
    }

    return result;
  } catch (error) {
    logger.error('Update order status error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Auftrag löschen
 */
export const deleteOrder = async (orderId) => {
  try {
    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('id', orderId);

    if (error) {
      logger.error('Error deleting order:', error);
      return { success: false, error: 'Fehler beim Löschen: ' + error.message };
    }

    return { success: true };
  } catch (error) {
    logger.error('Delete order error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Kommentar zu Auftrag hinzufügen (ERWEITERT)
 */
export const addCommentToOrder = async (orderId, commentText) => {
  try {
    const order = await getOrderById(orderId);
    if (!order) {
      return { success: false, error: 'Auftrag nicht gefunden.' };
    }

    const currentUser = await getCurrentUser();
    const { data: userData } = await supabase
      .from('users')
      .select('first_name, last_name, profile_picture')
      .eq('id', currentUser.id)
      .single();

    const authorName = userData
      ? `${userData.first_name} ${userData.last_name}`
      : 'Unbekannt';

    const authorProfilePicture = userData?.profile_picture || null;

    // Erstelle Kommentar
    const newComment = {
      id: `note_${Date.now()}`,
      type: 'comment',
      text: commentText,
      author: authorName,
      author_id: currentUser.id,
      timestamp: new Date().toISOString(),
    };

    // Füge zu notes hinzu
    const updatedNotes = [...(order.notes || []), newComment];

    const result = await updateOrder(orderId, { notes: updatedNotes });

    // ✅ Send notification to assigned users (except the comment author)
    if (result.success && order.assigned_to && order.assigned_to.length > 0) {
      try {
        const companyId = await getCurrentCompanyId();
        // Filter out the author - they shouldn't get notified about their own comment
        const recipientIds = order.assigned_to.filter(userId => userId !== currentUser.id);

        if (recipientIds.length > 0) {
          await notificationService.sendOrderCommentNotification({
            orderId: order.id,
            orderTitle: order.title,
            orderNumber: order.order_number || null,  // TODO: Add order_number field to orders table
            assignedUserIds: recipientIds,
            companyId,
            authorId: currentUser.id,
            authorName,
            authorProfilePicture,
            commentText,
          });
        }
      } catch (notifError) {
        logger.error('Error sending comment notification:', notifError);
      }
    }

    return result;
  } catch (error) {
    logger.error('Add comment error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Kommentar löschen
 */
export const deleteComment = async (orderId, commentId) => {
  try {
    const order = await getOrderById(orderId);
    if (!order) {
      return { success: false, error: 'Auftrag nicht gefunden.' };
    }

    const updatedNotes = (order.notes || []).filter(note => note.id !== commentId);

    const result = await updateOrder(orderId, { notes: updatedNotes });

    return result;
  } catch (error) {
    logger.error('Delete comment error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

// ============================================================================
// FOLDERS (Ordner)
// ============================================================================

/**
 * Alle Ordner der Company laden
 */
export const getFolders = async () => {
  try {
    const { data, error } = await supabase
      .from('folders')
      .select('*')
      .order('sort_order', { ascending: true });

    if (error) {
      logger.error('Error fetching folders:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    logger.error('Get folders error:', error);
    return [];
  }
};

/**
 * Ordner erstellen
 */
export const createFolder = async (folderData) => {
  try {
    const companyId = await getCurrentCompanyId();
    if (!companyId) {
      return { success: false, error: 'Nicht eingeloggt.' };
    }

    const { data, error } = await supabase
      .from('folders')
      .insert({
        company_id: companyId,
        name: folderData.name,
        color: folderData.color || '#6326ad',
        icon: folderData.icon || 'folder',
        sort_order: folderData.sortOrder || 0,
      })
      .select()
      .single();

    if (error) {
      logger.error('Error creating folder:', error);
      return { success: false, error: 'Fehler beim Erstellen: ' + error.message };
    }

    return { success: true, data: data };
  } catch (error) {
    logger.error('Create folder error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Ordner aktualisieren
 */
export const updateFolder = async (folderId, updates) => {
  try {
    const { data, error } = await supabase
      .from('folders')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', folderId)
      .select()
      .single();

    if (error) {
      logger.error('Error updating folder:', error);
      return { success: false, error: 'Fehler beim Aktualisieren: ' + error.message };
    }

    return { success: true, data: data };
  } catch (error) {
    logger.error('Update folder error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Ordner löschen
 */
export const deleteFolder = async (folderId) => {
  try {
    const { error } = await supabase
      .from('folders')
      .delete()
      .eq('id', folderId);

    if (error) {
      logger.error('Error deleting folder:', error);
      return { success: false, error: 'Fehler beim Löschen: ' + error.message };
    }

    return { success: true };
  } catch (error) {
    logger.error('Delete folder error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Auftrag in Ordner verschieben
 */
export const moveOrderToFolder = async (orderId, folderId) => {
  try {
    const result = await updateOrder(orderId, { folder_id: folderId });
    return result;
  } catch (error) {
    logger.error('Move order error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

// ============================================================================
// USERS (Mitarbeiter)
// ============================================================================

/**
 * Alle Mitarbeiter der Company laden
 */
export const getUsers = async () => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('Error fetching users:', error);
      return [];
    }

    return data || [];
  } catch (error) {
    logger.error('Get users error:', error);
    return [];
  }
};

/**
 * Mitarbeiter löschen
 * WICHTIG: Löscht User aus public.users Tabelle
 * Auth-User (auth.users) wird automatisch via Database Trigger gelöscht
 * (siehe RLS_FIX_USERS_DELETE.sql Migration)
 */
export const deleteUser = async (userId) => {
  try {
    // 1. Lösche User aus public.users Tabelle
    // NOTE: Database Trigger löscht automatisch auth.users Eintrag
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', userId);

    if (error) {
      logger.error('Error deleting user from public.users:', error);
      return { success: false, error: 'Fehler beim Löschen: ' + error.message };
    }

    logger.orders('✅ User deleted from public.users (auth.users deleted via trigger)');
    return { success: true };
  } catch (error) {
    logger.error('Delete user error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

// ============================================================================
// INVITATION CODES
// ============================================================================

/**
 * Invitation Code erstellen (Employee Key)
 */
export const createInvitationCode = async (email, role = 'employee', permissions = null) => {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return { success: false, error: 'Nicht eingeloggt.' };
    }

    // Hole company_id aus users-Tabelle
    const companyId = await getCurrentCompanyId();
    if (!companyId) {
      return { success: false, error: 'Keine Company ID gefunden.' };
    }

    // Prüfe ob Company wirklich existiert
    const { data: companyExists, error: companyCheckError } = await supabase
      .from('companies')
      .select('id')
      .eq('id', companyId)
      .single();

    if (companyCheckError || !companyExists) {
      logger.error('Company does not exist:', companyId);
      return {
        success: false,
        error: 'Dein Unternehmen wurde nicht gefunden. Bitte kontaktiere den Support oder registriere dich neu.'
      };
    }

    // Generiere Code
    const code = Math.random().toString(36).substring(2, 10).toUpperCase();

    // Ablaufdatum: 24 Stunden
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    // Prepare insert object
    const insertData = {
      code: code,
      email: email,
      role: role,
      expires_at: expiresAt.toISOString(),
      sent_by: currentUser.id,
      company_id: companyId,
      key_type: 'employee',
      used: false,
    };

    // Add permissions for co-admins
    if (role === 'co-admin' && permissions) {
      insertData.co_admin_permissions = permissions;
    }

    const { data, error } = await supabase
      .from('invitation_codes')
      .insert(insertData)
      .select()
      .single();

    if (error) {
      logger.error('Error creating invitation:', error);
      return { success: false, error: 'Fehler beim Erstellen: ' + error.message };
    }

    return { success: true, data: data };
  } catch (error) {
    logger.error('Create invitation error:', error);
    return { success: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Abgelaufene Invitation Codes löschen
 */
export const cleanupExpiredInvitationCodes = async () => {
  try {
    const { data, error } = await supabase
      .from('invitation_codes')
      .delete()
      .lt('expires_at', new Date().toISOString())
      .select();

    if (error) {
      logger.error('Error cleaning up expired codes:', error);
      return { success: false, error: error.message };
    }

    logger.orders(`✅ Cleanup: ${data?.length || 0} abgelaufene Invitation Codes gelöscht`);
    return { success: true, deletedCount: data?.length || 0 };
  } catch (error) {
    logger.error('Cleanup error:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Invitation Code validieren (Admin oder Employee Key)
 */
export const validateInvitationCode = async (code) => {
  try {
    // Cleanup abgelaufene Codes beim Validieren
    await cleanupExpiredInvitationCodes();

    const { data, error } = await supabase
      .from('invitation_codes')
      .select('*, companies(*)')
      .eq('code', code.toUpperCase())
      .eq('used', false)
      .gt('expires_at', new Date().toISOString())
      .single();

    if (error || !data) {
      return { valid: false, error: 'Ungültiger oder abgelaufener Code.' };
    }

    return {
      valid: true,
      data: data,
      keyType: data.key_type,
      company: data.companies || null,
    };
  } catch (error) {
    logger.error('Validate invitation error:', error);
    return { valid: false, error: 'Unerwarteter Fehler: ' + error.message };
  }
};

/**
 * Invitation Code als verwendet markieren
 * Setzt used=true für Audit Trail (Codes bleiben in DB)
 *
 * NOTE: DELETE funktioniert nicht wegen RLS Policy - nur Admins dürfen löschen,
 * aber Employee versucht seinen eigenen Code zu markieren.
 * UPDATE ist auch besser für Audit Trail und Nachvollziehbarkeit.
 */
export const markInvitationAsUsed = async (code, userId) => {
  try {
    const { error } = await supabase
      .from('invitation_codes')
      .update({
        used: true,
        used_by: userId,
        used_at: new Date().toISOString(),
      })
      .eq('code', code.toUpperCase());

    if (error) {
      logger.error('Error marking invitation code as used:', error);
      return { success: false, error: error.message };
    }

    logger.orders('✅ Invitation code marked as used');
    return { success: true };
  } catch (error) {
    logger.error('Mark invitation as used error:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Alle Employee Invitation Codes der Company abrufen
 */
export const getCompanyInvitationCodes = async () => {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return { success: false, error: 'Nicht eingeloggt.', data: [] };
    }

    const { data, error } = await supabase
      .from('invitation_codes')
      .select('*')
      .eq('company_id', currentUser.company_id)
      .eq('key_type', 'employee')
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('Error fetching invitation codes:', error);
      return { success: false, error: error.message, data: [] };
    }

    return { success: true, data: data || [] };
  } catch (error) {
    logger.error('Get invitation codes error:', error);
    return { success: false, error: error.message, data: [] };
  }
};
